#!/usr/bin/env python3
"""Build the dependency-free offline demo. Python 3.9+, no packages needed."""
from pathlib import Path
import json, re, hashlib
ROOT = Path(__file__).resolve().parent

def kebab(name):
    return re.sub(r'([A-Z])', lambda m: '-'+m[1].lower(), name)

def build():
    t = json.loads((ROOT/'src/tokens.json').read_text('utf-8'))
    css = ':root{' + ''.join('--'+kebab(k)+':'+v+';' for k,v in t['dark'].items())
    geom = {'ui-font':t['typography']['ui'],'control':t['geometry']['control'],'r-control':6,'rail':t['geometry']['rail'],'header':t['geometry']['header'],'tree-row':t['geometry']['treeRow'],'radius':t['geometry']['radius'],'pane-gap':t['geometry']['gap'],'left-width':t['geometry']['leftWidth'],'right-width':t['geometry']['rightWidth'],'compact-control':t['geometry']['compactControl'],'menu-row':t['geometry']['menuRow'],'footer-height':t['geometry']['footerHeight']}
    geom.update({kebab(k):t['geometry'][k] for k in ['railControl','railGap','topbarHeight','searchHeight','searchInline','searchGap','topControlGap']})
    css += ''.join('--'+k+':'+str(v)+'px;' for k,v in geom.items())
    css += ''.join('--font-'+kebab(k)+':'+str(v)+('' if k=='bodyLine' else 'px')+';' for k,v in t['typography'].items())+'color-scheme:dark}\n'
    css += '[data-theme="light"]{'+''.join('--'+kebab(k)+':'+v+';' for k,v in t['light'].items())+'color-scheme:light}\n'
    css += (ROOT/'src/styles.css').read_text('utf-8')
    js = 'globalThis.WBTokens='+json.dumps(t,ensure_ascii=False)+';\n'+'\n'.join((ROOT/'src'/p).read_text('utf-8') for p in ['icons.js','model.js','select-control.js','app.js'])
    if re.search(r'</script',js,re.I): raise ValueError('Source contains unsafe script closing sequence')
    html = '<!doctype html>\n<html lang="zh-CN" data-theme="dark"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="dark light"><title>AIALRA Workbench</title><style id="design-style">'+css+'</style></head><body><noscript>请启用 JavaScript 以操作本地工作台。</noscript><script id="initial-state" type="application/json">null</script><script id="app-code">'+js+'</script></body></html>'
    out=ROOT/'Workbench.html';out.write_text(html,'utf-8')
    info={'version':t['version'],'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'bytes':out.stat().st_size,'source_files':{p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'src').iterdir()) if p.is_file()}}
    (ROOT/'build.json').write_text(json.dumps(info,ensure_ascii=False,indent=2),'utf-8')
    print(out, info['sha256'])
if __name__=='__main__':build()
