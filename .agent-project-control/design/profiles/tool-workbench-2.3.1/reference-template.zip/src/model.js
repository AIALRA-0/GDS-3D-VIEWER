/* Pure, testable demo model. No network, no OS filesystem access. */
(function(g){'use strict';
const clone=x=>JSON.parse(JSON.stringify(x));
const uid=()=> 'n-'+(globalThis.crypto?.randomUUID?.()||Date.now().toString(36)+'-'+Math.random().toString(36).slice(2));
const now=()=>new Date().toISOString();
const fail=m=>{throw new Error(m)};
const profile=g.WBTokens||(typeof require==='function'?require('./tokens.json'):null);
const geometry=profile.geometry;
function createSeed(){
 const t=now();
 const body='# 文档标题\n\n摘要占位。\n\n## 内容区块\n\n正文内容占位。替换为当前项目需要展示的信息。\n\n- 条目 01\n- 条目 02\n- 条目 03\n\n## 补充内容\n\n[在这里放置当前项目的内容]';
 const base=(id,parent,name,type,content='')=>({id,parent,name,type,content,created:t,modified:t,versions:type==='folder'?[]:[{number:1,time:t,content}],draft:null});
 const seed={schema:2,revision:0,config:{name:'Workspace',theme:'dark',density:'comfortable',gap:geometry.gap,radius:geometry.radius,leftWidth:geometry.leftWidth,rightWidth:geometry.rightWidth,leftView:'explorer',hideLeft:false,hideRight:false},nodes:[
 base('project-1','#','项目 01','folder'),base('doc-1','project-1','文档 01.md','document',body),base('list-1','project-1','列表 01','table'),base('canvas-1','project-1','画布 01','canvas'),base('assets','project-1','资料','folder'),base('doc-2','assets','文档 02.md','document','# 文档标题\n\n[正文占位]'),base('project-2','#','项目 02','folder'),base('doc-3','project-2','文档 03.md','document','# 另一个文档\n\n[正文占位]')],trash:[],openFolders:['project-1','assets','project-2'],tabs:['doc-1','list-1','canvas-1'],active:'doc-1',selected:['doc-1'],listRows:[{id:'row-1',name:'条目 01',kind:'文本',note:''},{id:'row-2',name:'条目 02',kind:'资料',note:''},{id:'row-3',name:'条目 03',kind:'文本',note:''}],graph:[{id:'g-1',label:'节点 01',x:64,y:140},{id:'g-2',label:'节点 02',x:300,y:64},{id:'g-3',label:'节点 03',x:300,y:236}],edges:[['g-1','g-2'],['g-1','g-3']],events:[]};
 seed.nodes.find(n=>n.id==='list-1').payload={rows:seed.listRows};seed.nodes.find(n=>n.id==='canvas-1').payload={graph:seed.graph,edges:seed.edges};delete seed.listRows;delete seed.graph;delete seed.edges;return seed;
}
function node(s,id){return s.nodes.find(n=>n.id===id)}
function children(s,id){return s.nodes.filter(n=>n.parent===id)}
function descendants(s,id){const ids=[id];for(let i=0;i<ids.length;i++){for(const n of children(s,ids[i]))if(!ids.includes(n.id))ids.push(n.id);}return ids;}
function path(s,id){let n=node(s,id),parts=[],seen=new Set();while(n&&!seen.has(n.id)){parts.unshift(n.name);seen.add(n.id);n=node(s,n.parent)}return parts.join('/');}
function topSelection(s,ids){const valid=[...new Set(ids)].filter(id=>node(s,id));return valid.filter(id=>!valid.some(other=>other!==id&&descendants(s,other).includes(id)));}
function validName(s,name,parent,except){if(typeof name!=='string'||!name.trim()||name.length>160)fail('名称需为 1–160 个字符');name=name.trim();if(name==='.'||name==='..'||/[\\/\x00-\x1f]/.test(name))fail('名称不能包含路径分隔符或控制字符');if(children(s,parent).some(n=>n.name===name&&n.id!==except))fail('此位置已有同名项目');return name;}
function destination(s,parent){if(parent!=='#'&&node(s,parent)?.type!=='folder')fail('目标文件夹不存在');}
function distinct(s,name,parent){let val=name,i=2;while(children(s,parent).some(n=>n.name===val)){val=`${name} (${i++})`;}return val;}
function create(s,parent,type,name){destination(s,parent);const n={id:uid(),parent,type,name:validName(s,name,parent),content:'',draft:null,created:now(),modified:now(),versions:type==='folder'?[]:[{number:1,time:now(),content:''}]};if(!['document','folder','table','canvas'].includes(type))fail('不支持的类型');if(type==='table')n.payload={rows:[]};if(type==='canvas')n.payload={graph:[],edges:[]};s.nodes.push(n);return n.id;}
function rename(s,id,name){const n=node(s,id);if(!n)fail('项目不存在');n.name=validName(s,name,n.parent,id);n.modified=now();}
function move(s,ids,parent){destination(s,parent);ids=topSelection(s,ids);if(!ids.length)fail('没有可移动的项目');const moving=new Set(ids);const names=new Set();for(const id of ids){const n=node(s,id);if(descendants(s,id).includes(parent))fail('不能移入自身或子目录');if(names.has(n.name)||children(s,parent).some(x=>x.name===n.name&&!moving.has(x.id)))fail('目标文件夹存在同名项目');names.add(n.name)}for(const id of ids){node(s,id).parent=parent;node(s,id).modified=now();}return ids;}
function duplicate(s,ids,parent){const result=[];for(const id of topSelection(s,ids)){const original=node(s,id),dest=parent??original.parent;destination(s,dest);const all=descendants(s,id).map(x=>clone(node(s,x))),mapping=new Map(all.map(x=>[x.id,uid()]));const rootName=distinct(s,original.name,dest);for(const n of all){const old=n.id;n.id=mapping.get(old);n.parent=old===id?dest:mapping.get(n.parent);if(old===id)n.name=rootName;n.created=now();n.modified=now();s.nodes.push(n)}result.push(mapping.get(id));}return result;}
function remove(s,ids){const roots=topSelection(s,ids),entries=[];for(const id of roots){const n=node(s,id),all=descendants(s,id);const e={id:uid(),rootId:id,originalParent:n.parent,deleted:now(),items:all.map(x=>clone(node(s,x)))};s.trash.push(e);entries.push(e.id);s.nodes=s.nodes.filter(x=>!all.includes(x.id));s.tabs=s.tabs.filter(x=>!all.includes(x));s.selected=s.selected.filter(x=>!all.includes(x));s.openFolders=s.openFolders.filter(x=>!all.includes(x));}if(!node(s,s.active))s.active=s.tabs[0]||null;return entries;}
function restore(s,entryId){const e=s.trash.find(x=>x.id===entryId);if(!e)fail('回收站项目不存在');const dest=e.originalParent==='#'||node(s,e.originalParent)?.type==='folder'?e.originalParent:'#';const all=clone(e.items),root=all.find(x=>x.id===e.rootId);root.parent=dest;root.name=distinct(s,root.name,dest);const conflicts=all.some(x=>node(s,x.id));if(conflicts)fail('恢复对象的标识发生冲突');s.nodes.push(...all);s.trash=s.trash.filter(x=>x.id!==entryId);return root.id;}
function save(s,id){const n=node(s,id);if(!n||n.type==='folder')fail('没有可保存的文档');if(n.draft===null||n.draft===n.content){n.draft=null;return false;}n.content=n.draft;n.draft=null;n.modified=now();n.versions.push({number:(n.versions.at(-1)?.number||0)+1,time:now(),content:n.content});return true;}
function restoreVersion(s,id,index){const n=node(s,id),v=n?.versions[index];if(!v)fail('版本不存在');n.draft=v.content;return save(s,id);}
function validateConfig(input={}){
 const c={...createSeed().config,...input};
 if(!['dark','light'].includes(c.theme)||!['comfortable','compact'].includes(c.density)||!['explorer','inspector'].includes(c.leftView))fail('主题、密度或布局配置无效');
 if(typeof c.name!=='string'||!c.name.trim()||c.name.length>40)fail('工作区名称需为 1–40 个字符');c.name=c.name.trim();
 for(const [key,min,max] of [['gap',8,24],['radius',4,12],['leftWidth',216,400],['rightWidth',216,400]])if(!Number.isFinite(c[key])||!Number.isInteger(c[key])||c[key]<min||c[key]>max)fail('布局尺寸超出支持范围');
 for(const key of ['hideLeft','hideRight'])if(typeof c[key]!=='boolean')fail('侧栏显示设置无效');
 return c;
}
function validate(input){
 if(!input||input.schema!==2||!Array.isArray(input.nodes)||input.nodes.length>3000||!Array.isArray(input.trash))fail('不是有效的工作台配置（schema 2）');
 const s=clone(input),seed=createSeed();s.config=validateConfig(s.config);
 if(!['dark','light'].includes(s.config.theme)||!['comfortable','compact'].includes(s.config.density)||!['explorer','inspector'].includes(s.config.leftView))fail('主题、密度或布局配置无效');
 if(typeof s.config.name!=='string'||!s.config.name.trim()||s.config.name.length>40)fail('工作区名称需为 1–40 个字符');
 for(const [k,min,max] of [['gap',8,24],['radius',4,12],['leftWidth',216,400],['rightWidth',216,400]])if(!Number.isFinite(s.config[k])||s.config[k]<min||s.config[k]>max)fail('布局尺寸超出支持范围');
 const ids=new Set();for(const n of s.nodes){if(!n||typeof n.id!=='string'||!/^[-a-zA-Z0-9_]+$/.test(n.id)||ids.has(n.id))fail('项目标识不合法或重复');ids.add(n.id);if(!['folder','document','table','canvas'].includes(n.type)||typeof n.content!=='string'||(n.draft!==null&&typeof n.draft!=='string')||!Array.isArray(n.versions))fail('项目字段无效');if(n.content.length>200000)fail('单文档过大');}
 for(const n of s.nodes){destination(s,n.parent);validName(s,n.name,n.parent,n.id);let p=n.parent,seen=new Set([n.id]);while(p!=='#'){if(seen.has(p))fail('文件树存在循环');seen.add(p);p=node(s,p).parent;}for(const v of n.versions)if(typeof v.content!=='string'||!Number.isInteger(v.number)||v.number<1)fail('版本字段无效');}
 for(const e of s.trash){if(!e||typeof e.id!=='string'||!/^[-a-zA-Z0-9_]+$/.test(e.id)||!Array.isArray(e.items)||!e.items.length||!e.items.some(n=>n.id===e.rootId))fail('回收站数据无效');const temp={...seed,nodes:clone(e.items),trash:[]};temp.nodes.find(n=>n.id===e.rootId).parent='#';validateTreeOnly(temp);}
 for(const key of ['tabs','selected','openFolders'])s[key]=Array.isArray(s[key])?[...new Set(s[key])].filter(id=>ids.has(id)):seed[key].filter(id=>ids.has(id));
 s.active=ids.has(s.active)?s.active:(s.tabs[0]||null);s.events=Array.isArray(s.events)?s.events.slice(-80):[];
 for(const n of s.nodes)validatePayload(n);for(const e of s.trash)for(const n of e.items)validatePayload(n);return s;
}


function graphCollision(graph,id,x,y,pad=geometry.graphClearance){
 const w=geometry.graphNodeWidth,h=geometry.graphNodeHeight;
 return graph.find(n=>n.id!==id&&x<n.x+w+pad&&x+w+pad>n.x&&y<n.y+h+pad&&y+h+pad>n.y)||null;
}
function freeGraphPosition(graph,id,x,y){
 x=Math.round(Math.max(0,Math.min(5000,x)));y=Math.round(Math.max(0,Math.min(5000,y)));
 if(!graphCollision(graph,id,x,y))return {x,y};
 const sx=geometry.graphNodeWidth+32,sy=geometry.graphNodeHeight+32;
 for(let r=1;r<=110;r++)for(let dy=-r;dy<=r;dy++)for(const dx of (Math.abs(dy)===r?Array.from({length:r*2+1},(_,i)=>i-r):[-r,r])){
  const nx=x+dx*sx,ny=y+dy*sy;if(nx>=0&&nx<=5000&&ny>=0&&ny<=5000&&!graphCollision(graph,id,nx,ny))return{x:nx,y:ny};
 }
 fail('没有可用的节点位置');
}
function moveGraph(s,fileId,id,x,y){
 const f=node(s,fileId),graph=f?.payload?.graph,g=graph?.find(n=>n.id===id);
 if(!g||!Number.isFinite(x)||!Number.isFinite(y)||x<0||y<0||x>5000||y>5000)fail('节点或坐标无效');
 if(graphCollision(graph,id,x,y))fail('与其他节点相交，已保留原位置');
 g.x=Math.round(x);g.y=Math.round(y);f.modified=now();return true;
}

function validatePayload(n){
 if(n.type==='table'){const rows=n.payload?.rows;if(!Array.isArray(rows)||rows.length>500)fail('列表数据无效或过大');const ids=new Set();for(const r of rows){if(!r||typeof r.id!=='string'||!/^[-a-zA-Z0-9_]+$/.test(r.id)||ids.has(r.id)||typeof r.name!=='string'||r.name.length>160||typeof r.kind!=='string')fail('列表字段无效');ids.add(r.id);}}
 if(n.type==='canvas'){const graph=n.payload?.graph,edges=n.payload?.edges;if(!Array.isArray(graph)||!Array.isArray(edges)||graph.length>100||edges.length>300)fail('画布数据无效或过大');const ids=new Set();for(const r of graph){if(!r||typeof r.id!=='string'||!/^[-a-zA-Z0-9_]+$/.test(r.id)||ids.has(r.id)||typeof r.label!=='string'||r.label.length>160||!Number.isFinite(r.x)||!Number.isFinite(r.y)||r.x<0||r.y<0||r.x>5000||r.y>5000)fail('画布字段或坐标无效');ids.add(r.id);}if(edges.some(e=>!Array.isArray(e)||e.length!==2||!ids.has(e[0])||!ids.has(e[1])))fail('画布连线无效');}
}
function validateTreeOnly(s){const ids=new Set(s.nodes.map(n=>n.id));if(ids.size!==s.nodes.length)fail('回收站标识重复');for(const n of s.nodes){if(typeof n.id!=='string'||!/^[-a-zA-Z0-9_]+$/.test(n.id)||typeof n.content!=='string'||!Array.isArray(n.versions)||!['folder','document','table','canvas'].includes(n.type))fail('回收站内容无效');validName(s,n.name,n.parent,n.id);destination(s,n.parent);let p=n.parent,seen=new Set([n.id]);while(p!=='#'){if(seen.has(p))fail('回收站存在循环');seen.add(p);p=node(s,p).parent;}}}
const api={clone,uid,now,createSeed,node,children,descendants,path,topSelection,validName,create,rename,move,duplicate,remove,restore,save,restoreVersion,validate,validateConfig,graphCollision,freeGraphPosition,moveGraph};g.WorkbenchModel=api;if(typeof module!=='undefined')module.exports=api;
})(globalThis);
