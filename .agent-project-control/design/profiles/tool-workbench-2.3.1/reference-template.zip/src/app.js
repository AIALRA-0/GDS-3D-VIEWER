(function(){'use strict';
const M=WorkbenchModel,I=WIcons,$=(q,root=document)=>root.querySelector(q),$$=(q,root=document)=>[...root.querySelectorAll(q)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const hash=s=>{let h=0;for(const c of s)h=((h<<5)-h+c.charCodeAt(0))|0;return String(h>>>0)};
const KEY='aialra.workbench.v2.'+hash(location.pathname);
const TYPES={document:'文档',folder:'文件夹',table:'列表',canvas:'画布'}, ICONS={document:'file',folder:'folder',table:'table',canvas:'graph'};
let state,storageProblem='',storageLocked=false,storageAvailable=true;
try{const initial=JSON.parse($('#initial-state').textContent||'null');state=initial?M.validate(initial):M.createSeed();}catch(e){state=M.createSeed();storageProblem='初始数据无效 · 已加载空白样板';}
try{const stored=localStorage.getItem(KEY);if(stored){try{state=M.validate(JSON.parse(stored));}catch(e){storageLocked=true;storageProblem='本机数据未读取；原记录未覆盖';}}}catch(e){storageAvailable=false;}
let activity='files',navMode='files',inspectorTab='properties',surface='files',editMode=false,query='',listQuery='',listAscending=true,focusId=state.selected[0]||state.active,selectionAnchor=focusId;
let undoState=null,clipboard=null,toastTimer=null,previewState='',graphZoom=1,graphOffset={x:0,y:0},selectedGraph=null;
let drawerView=null,modalSubmit=null,modalReturn=null,menus=[],tooltipTimer=null,lastFocus=null,renameId=null,restoring=false;
const iconButton=(icon,label,action,extra='')=>`<button type="button" class="icon-button" aria-label="${esc(label)}" data-tip="${esc(label)}" data-action="${esc(action)}" ${extra}>${I(icon)}</button>`;
const actions=(...items)=>items.filter(Boolean);
const n=()=>M.node(state,state.active);
const data=(s=state)=>M.node(s,s.active)?.payload||{rows:[],graph:[],edges:[]};
const selected=()=>state.selected.filter(id=>M.node(state,id));
const selectedNode=()=>M.node(state,selected()[0]);

// Stable identities survive component rerenders; a detached DOM reference is not a focus policy.
const viewMemory=new Map(),propertyDrafts=new Map();
let lastMainId=null,menuHoverTimer=null,tooltipCloseTimer=null,tooltipOwner=null,drawerReturn=null;
let undoAfter=null,renderDepth=0,composing=false,suppressOutsideClick=false,activeCancel=null;
let settingsSection='appearance',settingsDirty=false,modalBusy=false,dialogGeneration=0,importGeneration=0;
let persistTimer=null,persistPending=false,firstDirtyAt=0,pendingDraft=false;
const runtimeStats={persistWrites:0,treeBuilds:0,graphBuilds:0,graphPaints:0,treeSelectionUpdates:0,commandIndexBuilds:0,paletteBuilds:0,panelMounts:0};

function frameTask(fn){let frame=0,pending=false,value;
 const task=v=>{value=v;pending=true;if(!frame)frame=requestAnimationFrame(()=>{frame=0;if(pending){pending=false;fn(value);}});};
 task.flush=()=>{if(frame)cancelAnimationFrame(frame);frame=0;if(pending){pending=false;fn(value);}};
 task.cancel=()=>{if(frame)cancelAnimationFrame(frame);frame=0;pending=false;};return task;
}
// UI state is immediate. Only its snapshot is deferred; explicit saves/exports flush it.
function schedulePersist(reason='draft'){
 if(!storageAvailable||storageLocked){renderStatus();return;}
 pendingDraft=pendingDraft||reason==='draft';persistPending=true;
 if(!firstDirtyAt)firstDirtyAt=performance.now();clearTimeout(persistTimer);
 const delay=pendingDraft?WBTokens.performance.draftSaveDelayMs:WBTokens.performance.viewSaveDelayMs;
 persistTimer=setTimeout(persist,Math.max(0,Math.min(delay,WBTokens.performance.draftSaveMaxWaitMs-(performance.now()-firstDirtyAt))));
 status(pendingDraft?'正在保存草稿…':'正在保存界面状态…');
}
const scheduleViewPersist=()=>schedulePersist('view');
function updateDirtyTab(f){const tab=$(`[data-tab="${f.id}"] .tab-open`);if(!tab)return;const dirty=f.draft!==null&&f.draft!==f.content,mark=$('.dirty-dot',tab);if(dirty&&!mark)tab.insertAdjacentHTML('beforeend','<i class="dirty-dot"></i>');else if(!dirty&&mark)mark.remove();}
const treeIndexes=new WeakMap();
function getTreeIndex(){let index=treeIndexes.get(state.nodes);if(index)return index;
 index={nodes:new Map(),children:new Map(),position:new Map(),paths:new Map(),fileCount:0};
 for(const n of state.nodes){index.nodes.set(n.id,n);if(n.type!=='folder')index.fileCount++;if(!index.children.has(n.parent))index.children.set(n.parent,[]);const siblings=index.children.get(n.parent);index.position.set(n.id,siblings.length+1);siblings.push(n);}
 const pathOf=id=>{if(index.paths.has(id))return index.paths.get(id);let current=index.nodes.get(id),trail=[],seen=new Set();
  while(current&&!index.paths.has(current.id)&&!seen.has(current.id)){seen.add(current.id);trail.push(current);current=index.nodes.get(current.parent);}
  let base=current?index.paths.get(current.id)||'':'';
  for(const node of trail.reverse()){base=base?base+'/'+node.name:node.name;index.paths.set(node.id,base);}return index.paths.get(id)||'';};
 for(const node of state.nodes)pathOf(node.id);
 treeIndexes.set(state.nodes,index);return index;
}
const queueTreeFilter=frameTask(()=>renderTree());
function switchSettings(section,focus=true){
 if(!['appearance','layout','workspace'].includes(section))section='appearance';
 WBSelect.close();settingsSection=section;
 for(const el of $$('.settings-section'))el.hidden=el.id!=='settings-'+section;
 for(const b of $$('.settings-tabs [role=tab]')){const active=b.dataset.section===section;b.setAttribute('aria-selected',String(active));b.tabIndex=active?0:-1;}
 if(focus)$('#settings-tab-'+section)?.focus({preventScroll:true});
}
function stageDefaultLayout(){
 const values={leftWidth:WBTokens.geometry.leftWidth,rightWidth:WBTokens.geometry.rightWidth,leftView:'explorer',hideLeft:false,hideRight:false};
 for(const [k,v] of Object.entries(values)){$(`[name="${k}"]`,$('#modal')).value=String(v);}
 WBSelect.enhance($('#modal'));refreshSettingsDirty();
}
function refreshSettingsDirty(){
 const form=$('#modal-form');if(!form||!$('#modal').classList.contains('settings-modal'))return;
 const fd=new FormData(form);settingsDirty=[...fd].some(([k,v])=>String(state.config[k])!==String(v));
 $('#modal-submit').disabled=!settingsDirty;$('#settings-status').textContent=settingsDirty?'有未应用的更改':'未更改';
}
function applyConfig(patch){
 const c=M.validateConfig({...state.config,...patch});state.config=c;
 state.events.push({id:M.uid(),time:M.now(),label:'更新工作台配置'});state.events=state.events.slice(-80);state.revision++;
 persist();applyLayout();renderStatus();
}

function focusRef(el=document.activeElement){
 if(!el||el===document.body)return null;
 const row=el.closest('[data-node]'),tab=el.closest('[data-tab]');
 return {el,id:el.id,node:row?.dataset.node,tab:tab?.dataset.tab,action:el.dataset.action,
  itemId:el.dataset.id,view:el.dataset.view,graph:el.dataset.graph,row:el.dataset.row,
  start:typeof el.selectionStart==='number'?el.selectionStart:null,end:el.selectionEnd,direction:el.selectionDirection,
  scroll:el.scrollTop};
}
function focusVisible(el){return !!el&&el.isConnected&&!el.disabled&&el.getClientRects().length>0&&!el.closest('[hidden]');}
function restoreFocus(ref,fallback=false){
 if(!ref){if(fallback)$('#main-content')?.focus({preventScroll:true});return;}
 let el=ref.el;
 if(!focusVisible(el))el=ref.id?document.getElementById(ref.id):null;
 if(!focusVisible(el)&&ref.node){const row=$(`[data-node="${CSS.escape(ref.node)}"]`);el=ref.action?row?.querySelector(`[data-action="${CSS.escape(ref.action)}"]`):row;}
 if(!focusVisible(el)&&ref.tab){const tab=$(`[data-tab="${CSS.escape(ref.tab)}"]`);el=tab?.querySelector(`[data-action="${CSS.escape(ref.action||'open')}"]`);}
 if(!focusVisible(el)&&ref.graph)el=$(`[data-graph="${CSS.escape(ref.graph)}"]`);
 if(!focusVisible(el)&&ref.row)el=$(`[data-row="${CSS.escape(ref.row)}"]`);
 if(!focusVisible(el)&&ref.action){let q=`[data-action="${CSS.escape(ref.action)}"]`;if(ref.itemId)q+=`[data-id="${CSS.escape(ref.itemId)}"]`;if(ref.view)q+=`[data-view="${CSS.escape(ref.view)}"]`;el=$$(q).find(focusVisible);}
 if(!focusVisible(el)&&fallback){el=$(`[data-node="${CSS.escape(focusId||'')}"]`);if(!focusVisible(el))el=$('#main-content');}
 if(focusVisible(el)){el.focus({preventScroll:true});if(ref.start!==null&&typeof el.setSelectionRange==='function'){try{el.setSelectionRange(ref.start,ref.end,ref.direction);el.scrollTop=ref.scroll||0;}catch{}}}
}
function overlayHost(){return $('#modal')?.open?$('#modal'):$('#palette')?.open?$('#palette'):$('#drawer')?.open?$('#drawer'):document.body;}
function rememberView(){
 const area=$('#main-content'),id=area?.dataset.fileId;if(!id)return;
 const prev=viewMemory.get(id)||{};prev.scrollTop=area.scrollTop;
 const ed=$('#document-editor');if(ed){prev.editorTop=ed.scrollTop;prev.start=ed.selectionStart;prev.end=ed.selectionEnd;}
 if($('#canvas-world')){prev.zoom=graphZoom;prev.offset={...graphOffset};}
 viewMemory.set(id,prev);
}
function restoreView(id){const saved=viewMemory.get(id);if(!saved)return;$('#main-content').scrollTop=saved.scrollTop||0;const ed=$('#document-editor');if(ed){ed.scrollTop=saved.editorTop||0;if(saved.start!=null)ed.setSelectionRange(saved.start,saved.end);}}
function treeTypeahead(key){const t=Date.now();treeTypeahead.value=t-(treeTypeahead.at||0)<650?(treeTypeahead.value||'')+key:key;treeTypeahead.at=t;const rows=visibleRows(),i=rows.findIndex(r=>r.node.id===focusId),ordered=rows.slice(i+1).concat(rows.slice(0,i+1));const target=ordered.find(r=>r.node.name.toLowerCase().startsWith(treeTypeahead.value.toLowerCase()));if(target)focusTree(target.node.id);}

const dateFormatter=new Intl.DateTimeFormat('zh-CN',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false});
function fmt(t){if(!t)return '—';try{return dateFormatter.format(new Date(t))}catch{return '—'}}
function persist(){
 clearTimeout(persistTimer);persistTimer=null;persistPending=false;firstDirtyAt=0;pendingDraft=false;
 if(!storageAvailable){status('会话存储 · 关闭前导出');return false;}
 if(storageLocked){status(storageProblem,true);return false;}
 try{localStorage.setItem(KEY,JSON.stringify(state));runtimeStats.persistWrites++;storageProblem='';status('本机存储');return true;}
 catch(e){storageProblem='保存失败 · 请导出备份';status(storageProblem,true);return false;}
}
function status(msg,error=false){const el=$('#storage-status');if(el){el.textContent=msg;el.style.color=error?'var(--danger)':'';}}
// Feedback must not cover the fixed canvas controls or the content footer.
function positionToast(){const el=$('#toast');if(!el||el.hidden)return;el.style.bottom='';if(overlayHost()!==document.body)return;
 const blockers=[$('.canvas-tools'),$('.main-foot')].filter(focusVisible);if(blockers.length){const top=Math.min(...blockers.map(x=>x.getBoundingClientRect().top));el.style.bottom=Math.max(44,innerHeight-top+8)+'px';}}
function notify(message,kind='info',action=null){clearTimeout(toastTimer);const el=$('#toast');overlayHost().append(el);el.className='toast'+(kind==='error'?' error':'');el.innerHTML=I(kind==='error'?'warning':'check')+`<span class="toast-message">${esc(message)}</span>`+(action?`<button class="toast-action" id="toast-action">${esc(action.label)}</button>`:'')+iconButton('close','关闭提示','close-toast');el.hidden=false;positionToast();el.setAttribute('role',kind==='error'?'alert':'status');if(action)$('#toast-action').onclick=action.run;toastTimer=setTimeout(()=>el.hidden=true,kind==='error'?9000:5500);}
function transact(fn,label){
 try{
  const before=M.clone(state),draft=M.clone(state),focus=focusRef();const result=fn(draft);
  draft.revision=(draft.revision||0)+1;draft.events.push({id:M.uid(),time:M.now(),label});draft.events=draft.events.slice(-80);
  state=M.validate(draft);
  if(!['保存文档','恢复文档版本'].includes(label)){undoState=before;undoAfter=M.clone(state);}
  persist();render();restoreFocus(focus);return result;
 }catch(e){if($('#modal')?.open&&$('#dialog-error')){$('#dialog-error').textContent=e.message;$('#dialog-error').hidden=false;}else notify(e.message,'error');return null;}
}
function undo(){
 if(!undoState)return notify('没有可撤销的操作');
 const restored=M.clone(undoState),current=state,after=undoAfter;
 if(after){
  // The undo owner is the structure action; later text input is not owned by it.
  const edited=f=>{const a=M.node(after,f.id);return a&&['content','draft','versions'].some(k=>JSON.stringify(f[k])!==JSON.stringify(a[k]));};
  if(current.nodes.some(f=>!M.node(restored,f.id)&&edited(f)))return notify('该项目已有后续编辑，未撤销。请先保留内容。','error');
  for(const f of current.nodes){const target=M.node(restored,f.id);if(target&&edited(f))for(const k of ['content','draft','versions','modified'])target[k]=M.clone(f[k]);}
  restored.tabs=[...new Set([...restored.tabs,...current.tabs])].filter(id=>M.node(restored,id));
  if(M.node(restored,current.active))restored.active=current.active;
 }
 state=M.validate(restored);undoState=null;undoAfter=null;persist();render();notify('已撤销结构操作；后续文字保留');
}
function openFile(id){
 const treeOrigin=!!document.activeElement?.closest('[role="tree"]'),file=M.node(state,id);if(!file)return;
 if(file.type==='folder'){toggleFolder(id);return;}
 const unchanged=state.active===id&&surface==='files'&&!previewState,selectionSame=state.selected.length===1&&state.selected[0]===id;
 rememberView();activity='files';surface='files';navMode='files';state.active=id;state.selected=[id];focusId=id;selectionAnchor=id;
 if(!state.tabs.includes(id))state.tabs.push(id);if(!unchanged)editMode=false;previewState='';expandAncestors(id);
 renderTree();if(!unchanged){renderTabs();renderMain();}if(!unchanged||!selectionSame)renderInspector();updateActivity();renderStatus();scheduleViewPersist();
 if(drawerView==='explorer'){closeDrawer();$('#main-content').focus({preventScroll:true});}else if(treeOrigin)focusTree(id);
}
function expandAncestors(id){let p=M.node(state,id)?.parent;while(p&&p!=='#'){if(!state.openFolders.includes(p))state.openFolders.push(p);p=M.node(state,p)?.parent;}}
function toggleFolder(id){const ref=focusRef();state.openFolders=state.openFolders.includes(id)?state.openFolders.filter(x=>x!==id):[...state.openFolders,id];renderTree();restoreFocus(ref);if(ref?.node===id)focusTree(id);scheduleViewPersist();}
function selectNode(id,event={}){if(event.shiftKey&&selectionAnchor){const rows=visibleRows().map(x=>x.node.id),a=rows.indexOf(selectionAnchor),b=rows.indexOf(id);state.selected=rows.slice(Math.min(a,b),Math.max(a,b)+1);}else if(event.ctrlKey||event.metaKey){state.selected=state.selected.includes(id)?state.selected.filter(x=>x!==id):[...state.selected,id];selectionAnchor=id;}else{state.selected=[id];selectionAnchor=id;}focusId=id;renderTree();renderInspector();scheduleViewPersist();const el=$(`[data-node="${id}"]`);el?.focus({preventScroll:true});}
function closeTab(id){rememberView();const ref=focusRef(),index=state.tabs.indexOf(id),wasActive=state.active===id;state.tabs=state.tabs.filter(x=>x!==id);if(wasActive){state.active=state.tabs[Math.min(Math.max(index,0),state.tabs.length-1)]||null;state.selected=state.active?[state.active]:[];focusId=state.active;selectionAnchor=focusId;}renderTabs();renderMain();renderTree();renderInspector();scheduleViewPersist();const b=$('.tab-open[aria-selected="true"]');if(ref?.tab===id&&b)b.focus({preventScroll:true});}
function visibleRows(){
 const index=getTreeIndex(),result=[],searching=query.trim().toLocaleLowerCase(),matching=new Set(),open=new Set(state.openFolders);
 if(searching)for(const node of state.nodes)if(node.name.toLocaleLowerCase().includes(searching)){
  matching.add(node.id);let p=node.parent;while(p!=='#'&&!matching.has(p)){matching.add(p);p=index.nodes.get(p)?.parent||'#';}
 }
 const stack=[...(index.children.get('#')||[])].reverse().map(node=>({node,depth:0}));
 while(stack.length){const row=stack.pop(),{node,depth}=row;if(searching&&!matching.has(node.id))continue;result.push(row);
  if(node.type==='folder'&&(searching||open.has(node.id)))for(const child of [...(index.children.get(node.id)||[])].reverse())stack.push({node:child,depth:depth+1});
 }return result;
}
function countActive(){return getTreeIndex().fileCount;}
function shell(){
$('#app').innerHTML=`<header class="topbar"><div class="brand">${I('workspace')}<b>AIALRA</b><span class="divider"></span><span class="workspace-title" id="workspace-title"></span></div><button class="command-trigger" data-action="palette" aria-label="搜索文件与命令"><span>${I('search')}</span><span class="label">搜索文件与命令</span><kbd class="key">Ctrl K</kbd></button><div class="top-controls">${iconButton('more','工作区菜单','workspace-menu').replace('icon-button','icon-button top-menu')}${iconButton('sun','切换浅色主题','theme')}${iconButton('leftPanel','显示或隐藏左侧栏','toggle-left')}${iconButton('rightPanel','显示或隐藏右侧栏','toggle-right')}</div></header>
<div class="work-area"><nav class="activity-rail" aria-label="工作区导航">${iconButton('files','文件','nav-files')}${iconButton('search','查找文件','nav-search')}${iconButton('trash','回收站','nav-trash')}${iconButton('components','组件参照','components')}<div class="spacer"></div>${iconButton('help','操作帮助','help')}${iconButton('settings','工作台设置','settings')}</nav>
<div class="layout" id="layout"><div class="slot" id="left-slot"><div class="drop-target" data-drop-side="left">移至左侧</div></div><div class="splitter" id="split-left" role="separator" tabindex="0" aria-label="调整左侧栏宽度" aria-orientation="vertical" aria-valuemin="216" aria-valuemax="400"></div><main class="main-pane" id="main-pane" aria-label="主要内容"><div class="tabs-bar"><div class="tabs" id="tabs" role="tablist" aria-label="已打开的文件"></div><div class="tabs-actions">${iconButton('plus','新建文档','create-document')}${iconButton('more','标签页菜单','tabs-menu')}</div></div><div class="main-toolbar"><nav class="breadcrumb" id="breadcrumb" aria-label="文件位置"></nav><div class="view-tools" id="view-tools"></div></div><div class="preview-banner" id="preview-banner" hidden></div><div class="main-content" id="main-content" tabindex="-1"></div><footer class="main-foot"><span class="save-state" id="save-state"></span><span id="main-meta"></span></footer></main><div class="splitter" id="split-right" role="separator" tabindex="0" aria-label="调整右侧栏宽度" aria-orientation="vertical" aria-valuemin="216" aria-valuemax="400"></div><div class="slot" id="right-slot"><div class="drop-target" data-drop-side="right">移至右侧</div></div></div></div>
<footer class="statusbar"><span id="storage-status">本机存储</span><div class="right-status"><span id="selection-status"></span><span class="optional">Reference</span><span>2.3</span></div></footer>`;
const explorer=document.createElement('section');explorer.className='pane';explorer.id='explorer';explorer.dataset.view='explorer';explorer.setAttribute('aria-label','文件资源管理器');explorer.innerHTML=paneHead('explorer','文件')+`<div class="filter-box" id="tree-filter">${I('search')}<input id="tree-search" aria-label="过滤文件" placeholder="过滤文件…" autocomplete="off">${iconButton('close','清除文件筛选','clear-tree-search','id="tree-clear" hidden')}</div><div class="tree-heading"><span id="tree-label">项目文件</span><div class="inline-actions">${iconButton('plus','新建项目','tree-new')}${iconButton('collapse','折叠全部文件夹','collapse-folders')}</div></div><div class="tree-scroll" id="tree-scroll"><div id="tree" role="tree" aria-label="项目文件" aria-multiselectable="true"></div><div id="trash-list" hidden></div></div><footer class="panel-foot" id="tree-foot"></footer>`;
const inspector=document.createElement('aside');inspector.className='pane';inspector.id='inspector';inspector.dataset.view='inspector';inspector.setAttribute('aria-label','对象属性');inspector.innerHTML=paneHead('inspector','检查器')+`<div class="inspector-content" id="inspector-content"></div><footer class="panel-foot" id="inspector-foot"></footer>`;
$('#left-slot').append(explorer);$('#right-slot').append(inspector);
}
function paneHead(view,title){return `<header class="pane-head"><button class="icon-button grip" draggable="false" data-view-grip="${view}" data-action="panel-menu" data-view="${view}" aria-label="拖动或迁移${title}" data-tip="拖动迁移；点击打开布局菜单">${I('grip')}</button><span class="pane-title">${title}</span><div class="pane-actions">${iconButton('swap','移至另一侧','swap-panels',`data-view="${view}"`)}${iconButton('more',`${title}操作`,'panel-menu',`data-view="${view}"`)}${iconButton('close',`收起${title}`,'hide-panel',`data-view="${view}"`)}</div></header>`;}
function physicalSide(view){return state.config.leftView===view?'left':'right';}
function currentMode(){return innerWidth>=1120?'wide':innerWidth>=760?'medium':'narrow';}
function mountPanels(){if(drawerView)return;const left=state.config.leftView,right=left==='explorer'?'inspector':'explorer';for(const [slot,view]of [['left-slot',left],['right-slot',right]]){const host=$('#'+slot),panel=$('#'+view);if(panel.parentElement!==host){host.append(panel);runtimeStats.panelMounts++;}}}
function applyLayout(){
 const c=state.config,root=document.documentElement;root.dataset.theme=c.theme;root.dataset.density=c.density;
 root.style.setProperty('--pane-gap',c.gap+'px');root.style.setProperty('--radius',c.radius+'px');
 root.style.setProperty('--tree-row',(c.density==='compact'?WBTokens.geometry.compactTreeRow:WBTokens.geometry.treeRow)+'px');mountPanels();
 const mode=currentMode(),lv=mode!=='narrow'&&!c.hideLeft,rv=mode==='wide'&&!c.hideRight;
 const area=$('#layout').clientWidth;let lw=c.leftWidth,rw=c.rightWidth;
 const budget=Math.max(0,area-WBTokens.geometry.mainMin-(lv?c.gap:0)-(rv?c.gap:0));
 if(lv&&rv&&lw+rw>budget){const extra=Math.max(0,budget-432),flex=lw+rw-432;lw=Math.round(216+extra*(flex>0?(lw-216)/flex:.5));rw=Math.floor(budget-lw);}
 else if(lv)lw=Math.max(216,Math.min(lw,budget));
 else if(rv)rw=Math.max(216,Math.min(rw,budget));
 root.style.setProperty('--left-width',lw+'px');root.style.setProperty('--right-width',rw+'px');
 $('#layout').style.gridTemplateColumns=`${lv?lw+'px':'0px'} ${lv?c.gap+'px':'0px'} minmax(0,1fr) ${rv?c.gap+'px':'0px'} ${rv?rw+'px':'0px'}`;
 $('#left-slot').hidden=!lv;$('#split-left').hidden=!lv;$('#right-slot').hidden=!rv;$('#split-right').hidden=!rv;
 for(const [side,width,opposite,on]of [['left',lw,rw,rv],['right',rw,lw,lv]]){const sep=$('#split-'+side);sep.setAttribute('aria-valuenow',Math.round(width));sep.setAttribute('aria-valuetext',Math.round(width)+' 像素');sep.setAttribute('aria-controls',side+'-slot');sep.setAttribute('aria-valuemax',Math.floor(Math.max(216,Math.min(400,area-WBTokens.geometry.mainMin-c.gap-(on?opposite+c.gap:0)))));}
 const leftButton=$('[data-action="toggle-left"]'),rightButton=$('[data-action="toggle-right"]');
 leftButton.setAttribute('aria-pressed',String(lv||!!drawerView&&physicalSide(drawerView)==='left'));rightButton.setAttribute('aria-pressed',String(rv||!!drawerView&&physicalSide(drawerView)==='right'));
 const themeBtn=$('[data-action="theme"]');themeBtn.innerHTML=I(c.theme==='dark'?'sun':'moon');themeBtn.setAttribute('aria-label',c.theme==='dark'?'切换浅色主题':'切换深色主题');themeBtn.dataset.tip=themeBtn.getAttribute('aria-label');$('#workspace-title').textContent=c.name;document.title=c.name+' · AIALRA';
}
function showPanel(view){const side=physicalSide(view),mode=currentMode();if(mode==='narrow'||mode==='medium'&&side==='right'){openDrawer(view);return;}const key=side==='left'?'hideLeft':'hideRight';if(state.config[key]){state.config[key]=false;applyLayout();scheduleViewPersist();}}
function toggleSide(side){const view=side==='left'?state.config.leftView:(state.config.leftView==='explorer'?'inspector':'explorer'),mode=currentMode();if(mode==='narrow'||mode==='medium'&&side==='right'){if(drawerView===view)closeDrawer();else openDrawer(view);return;}state.config[side==='left'?'hideLeft':'hideRight']=!state.config[side==='left'?'hideLeft':'hideRight'];applyLayout();scheduleViewPersist();}
function hidePanel(view){if(drawerView===view){closeDrawer();return;}const side=physicalSide(view);state.config[side==='left'?'hideLeft':'hideRight']=true;applyLayout();scheduleViewPersist();$(`[data-action="toggle-${side}"]`)?.focus({preventScroll:true});}
function swapPanels(targetSide=null,view=null){if(drawerView)closeDrawer();const target=targetSide&&view?(targetSide==='left'?view:(view==='explorer'?'inspector':'explorer')):(state.config.leftView==='explorer'?'inspector':'explorer');state.config.leftView=target;state.config.hideLeft=false;state.config.hideRight=false;applyLayout();scheduleViewPersist();notify('侧栏位置已更新');}
function openDrawer(view){const ref=focusRef();if($('#drawer').open)closeDrawer();hideMenus();hideTip();drawerReturn=ref;drawerView=view;const d=$('#drawer');d.dataset.side=physicalSide(view);d.setAttribute('aria-label',view==='explorer'?'文件资源管理器':'对象属性');d.setAttribute('aria-modal','true');d.append($('#'+view));d.showModal();applyLayout();d.querySelector('button:not(.grip)')?.focus();}
function closeDrawer(){hideMenus();hideTip();const d=$('#drawer');const ref=drawerReturn;if(d.open)d.close();drawerView=null;mountPanels();applyLayout();overlayHost().append($('#toast'));positionToast();restoreFocus(ref,true);}
function render(){const ref=focusRef();renderDepth++;applyLayout();renderTree();renderTabs();renderMain();renderInspector();updateActivity();renderStatus();renderDepth--;restoreFocus(ref);}
function renderStatus(){status(storageProblem||(persistPending?(pendingDraft?'正在保存草稿…':'正在保存界面状态…'):storageAvailable?'本机存储':'会话存储 · 关闭前导出'),!!storageProblem);$('#selection-status').textContent=selected().length>1?`${selected().length} 项已选择`:`${countActive()} 个文件`;}
function updateActivity(){
 const routes={'nav-files':'files','nav-search':'search','nav-trash':'trash','components':'components'};
 for(const [cmd,value]of Object.entries(routes)){
  const b=$(`[data-action="${cmd}"]`);const active=activity===value;
  b.dataset.nav=value;b.setAttribute('aria-pressed',String(active));b.tabIndex=active?0:-1;
  if(active)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');
 }
 $('#explorer .pane-title').textContent=activity==='search'?'搜索':navMode==='trash'?'回收站':'文件';
}
let treeCache=null,treeSelectionIds=[],treeFocusId=null,treeDom=new Map();
function syncTreeSelection(){
 const affected=new Set([...treeSelectionIds,...state.selected,treeFocusId,focusId]);
 for(const id of affected){const row=treeDom.get(id);if(!row?.isConnected)continue;const selected=state.selected.includes(id),tab=focusId===id?'0':'-1';
  if(row.getAttribute('aria-selected')!==String(selected))row.setAttribute('aria-selected',String(selected));
  if(row.getAttribute('tabindex')!==tab)row.setAttribute('tabindex',tab);
 }
 treeSelectionIds=state.selected.slice();treeFocusId=focusId;runtimeStats.treeSelectionUpdates++;
}
function renderTree(){const index=getTreeIndex();const hadFocus=!!document.activeElement?.closest('#tree'),ref=hadFocus?focusRef():null;const tree=$('#tree'),list=$('#trash-list');tree.hidden=navMode!=='files';list.hidden=navMode!=='trash';$('#tree-filter').hidden=navMode==='trash';$('#tree-label').textContent=navMode==='trash'?'回收站':'项目文件';$('#tree-search').value=query;$('#tree-clear').hidden=!query;$('#tree-foot').innerHTML=navMode==='trash'?`${I('trash')}<span>${state.trash.length} 项 · 仅本机演示数据</span>`:`${I('folder')}<span>${state.nodes.length} 个项目</span>`;
 if(navMode==='trash'){list.innerHTML=state.trash.length?state.trash.map(e=>{const node=e.items.find(x=>x.id===e.rootId);return `<div class="trash-row" data-trash="${e.id}" tabindex="0"><span>${I(ICONS[node.type])}</span><div class="trash-info"><div class="trash-name">${esc(node.name)}</div><small>${esc(fmt(e.deleted))}${e.items.length>1?' · '+e.items.length+' 项':''}</small></div>${iconButton('restore','恢复项目','restore',`data-entry="${e.id}"`)}${iconButton('more','回收站项目操作','trash-menu',`data-entry="${e.id}"`)}</div>`}).join(''):`<div class="no-results">${I('trash')}回收站为空</div>`;return;}
 const shape=JSON.stringify([state.openFolders,query,clipboard?.mode,clipboard?.ids]);
 if(treeCache&&treeCache.nodes===state.nodes&&treeCache.shape===shape){syncTreeSelection();renderStatus();if(ref)restoreFocus(ref);return;}
 runtimeStats.treeBuilds++;const rows=visibleRows();treeCache={nodes:state.nodes,shape};tree.style.minWidth=Math.max(0,Math.max(0,...rows.map(r=>r.depth))*16+184)+'px';if(!rows.some(r=>r.node.id===focusId))focusId=rows[0]?.node.id;
 tree.innerHTML=rows.map(({node,depth})=>`<div class="tree-row ${clipboard?.mode==='cut'&&clipboard.ids.includes(node.id)?'cut':''}" id="tree-${node.id}" data-node="${node.id}" role="treeitem" aria-level="${depth+1}" aria-posinset="${index.position.get(node.id)}" aria-setsize="${index.children.get(node.parent).length}" aria-selected="${state.selected.includes(node.id)}" ${node.type==='folder'?`aria-expanded="${!!query||state.openFolders.includes(node.id)}"`:''} tabindex="${focusId===node.id?'0':'-1'}" draggable="false" style="--depth:${depth}"><button type="button" class="chevron" tabindex="-1" data-action="toggle-folder" data-id="${node.id}" ${node.type==='folder'?`aria-label="展开或收起${esc(node.name)}"`:'disabled aria-hidden="true"'}>${node.type==='folder'?I(state.openFolders.includes(node.id)||query?'down':'right'):''}</button>${I(node.type==='folder'&&state.openFolders.includes(node.id)?'folderOpen':ICONS[node.type])}<span class="tree-name" data-tip="${esc(node.name)}">${esc(node.name)}</span>${iconButton('more','项目操作：'+node.name,'node-menu',`data-id="${node.id}" tabindex="-1"`) .replace('icon-button','icon-button row-more')}</div>`).join('')||`<div class="no-results">${I('search')}${query?'没有匹配的文件':'暂无文件'}</div>`;
 treeDom=new Map(rows.map(r=>[r.node.id,document.getElementById('tree-'+r.node.id)]));treeSelectionIds=state.selected.slice();treeFocusId=focusId;
 renderStatus();if(ref)restoreFocus(ref);}
function renderTabs(){const ref=document.activeElement?.closest('#tabs')?focusRef():null;const tabs=$('#tabs');tabs.innerHTML=state.tabs.filter(id=>M.node(state,id)).map(id=>{const f=M.node(state,id);return `<div class="doc-tab ${surface==='files'&&state.active===id?'active':''}" data-tab="${id}"><button class="tab-open" data-tip="${esc(f.name)}" data-action="open" data-id="${id}" role="tab" aria-selected="${surface==='files'&&state.active===id}" aria-controls="main-content" tabindex="${surface==='files'&&state.active===id?'0':'-1'}">${I(ICONS[f.type])}<span>${esc(f.name)}</span>${f.draft!==null&&f.draft!==f.content?'<i class="dirty-dot"></i>':''}</button>${iconButton('close','关闭 '+f.name,'close-tab',`data-id="${id}"`).replace('icon-button','icon-button tab-close')}</div>`}).join('');if(surface==='components')tabs.insertAdjacentHTML('beforeend',`<div class="doc-tab active"><button class="tab-open" role="tab" aria-selected="true">${I('components')}<span>组件参照</span></button>${iconButton('close','关闭组件参照','close-components').replace('icon-button','icon-button tab-close')}</div>`);restoreFocus(ref);$('.doc-tab.active')?.scrollIntoView({block:'nearest',inline:'nearest'});}
function renderMain(){rememberView();const f=n(),content=$('#main-content');content.dataset.fileId=state.active||'';$('#preview-banner').hidden=!previewState;
 if(previewState){content.dataset.fileId='';$('#preview-banner').innerHTML=`<span>状态预览 · ${previewState==='loading'?'加载':previewState==='error'?'错误':'空内容'}</span><button data-action="exit-preview">退出预览</button>`;$('#view-tools').innerHTML='';content.innerHTML=previewHTML();$('#save-state').textContent='仅演示状态 · 不更改原内容';return;}
 if(surface==='components'){content.dataset.fileId='';renderComponents();return;}
 if(!f){$('#breadcrumb').textContent='工作区';$('#view-tools').innerHTML='';content.innerHTML=`<div class="empty-view">${I('workspace')}<h2>选择一个文件</h2><p>从侧栏打开文件，或新建一个文档</p><button class="text-button" data-action="create-document">${I('plus')}新建文档</button></div>`;$('#save-state').textContent='就绪';$('#main-meta').textContent='';return;}
 $('#breadcrumb').innerHTML=M.path(state,f.id).split('/').map(esc).join(I('right'));
 $('#view-tools').innerHTML=(f.type==='document'?iconButton('eye','阅读预览','preview',`aria-pressed="${!editMode}"`)+iconButton('edit','编辑文档','edit',`aria-pressed="${editMode}"`)+iconButton('save','保存文档','save',`${f.draft===null||f.draft===f.content?'disabled':''}`):'')+iconButton('more','当前文件操作','active-menu');
 if(f.type==='document'){if(editMode){content.innerHTML=`<div class="editor-wrap"><label class="editor-label" for="document-editor"><span>Markdown</span><span>Ctrl S 保存</span></label><textarea class="editor-input" id="document-editor" spellcheck="false" aria-label="文档内容" placeholder="在此输入内容…">${esc(f.draft??f.content)}</textarea></div>`;}else{content.innerHTML=`<article class="document-page"><div class="doc-marker">${I('file')}<span>文档</span></div>${markdown(f.draft??f.content)}</article>`;}}
 else if(f.type==='table')renderTable();else if(f.type==='canvas')renderCanvas();
 updateSaveState();restoreView(state.active);}
function markdown(text){if(!text)return '<h1>文档标题</h1><p class="placeholder-line">[正文内容占位]</p>';let out='',inList=false;for(const line of text.split('\n')){if(line.startsWith('- ')){if(!inList){out+='<ul>';inList=true;}out+='<li>'+esc(line.slice(2))+'</li>';continue;}if(inList){out+='</ul>';inList=false;}if(line.startsWith('# '))out+='<h1>'+esc(line.slice(2))+'</h1>';else if(line.startsWith('## '))out+='<h2>'+esc(line.slice(3))+'</h2>';else if(line.trim())out+='<p>'+esc(line)+'</p>';}return out+(inList?'</ul>':'');}
function updateSaveState(){const f=n();if(!f)return;const dirty=f.draft!==null&&f.draft!==f.content;$('#save-state').innerHTML=dirty?'<i class="dirty-dot"></i><span>未提交的修改</span>':I('check')+'<span>'+(storageAvailable?'已保存到本机':'已保存到本次会话')+'</span>';if(storageProblem)$('#save-state').textContent=storageProblem;$('#main-meta').textContent=f.type==='document'?`${(f.draft??f.content).length} 字符`:(f.type==='table'?`${data().rows.length} 条记录`:`${data().graph.length} 个节点`);const save=$('[data-action="save"]');if(save)save.disabled=!dirty&&!storageProblem;}
function renderInspector(){const el=$('#inspector-content'),selectedFile=selectedNode()||n();$('#inspector-foot').textContent=selected().length>1?`${selected().length} 项已选择`:(selectedFile?TYPES[selectedFile.type]:'未选择对象');el.innerHTML=`<div class="inspector-tabs" id="inspector-tabs" role="tablist" aria-label="检查器视图"><button role="tab" id="inspector-tab-properties" data-action="inspector-properties" tabindex="${inspectorTab==='properties'?0:-1}" aria-selected="${inspectorTab==='properties'}">属性</button><button role="tab" id="inspector-tab-history" data-action="inspector-history" tabindex="${inspectorTab==='history'?0:-1}" aria-selected="${inspectorTab==='history'}">版本</button></div>`;
 if(!selectedFile){el.insertAdjacentHTML('beforeend',`<p class="hint-text">选择一个项目以查看属性</p>`);return;}
 if(selected().length>1){el.insertAdjacentHTML('beforeend',`<div class="select-title">${I('files')}<div><h3>${selected().length} 个项目</h3><small>已选择</small></div></div><div class="properties-actions"><button class="text-button" data-action="move-selected">移动…</button><button class="text-button" data-action="delete-selected">移入回收站</button></div>`);return;}
 if(inspectorTab==='history'&&selectedFile.type!=='document'){el.insertAdjacentHTML('beforeend','<p class="hint-text">此类型不提供文档版本</p>');return;}
 if(inspectorTab==='history'){el.insertAdjacentHTML('beforeend',selectedFile.versions.length?selectedFile.versions.slice().reverse().map((v,idx)=>`<div class="version-row">${I('history')}<div class="version-body">版本 ${v.number}<small>${fmt(v.time)}</small></div>${iconButton('eye','查看版本 '+v.number,'view-version',`data-id="${selectedFile.id}" data-version="${selectedFile.versions.length-1-idx}"`)}</div>`).join(''):`<p class="hint-text">文件夹没有文档版本</p>`);return;}
 el.insertAdjacentHTML('beforeend',`<div class="select-title">${I(ICONS[selectedFile.type])}<div><h3>${esc(selectedFile.name)}</h3><small>${TYPES[selectedFile.type]}</small></div></div><div class="property-group"><label class="field"><span>名称</span><div class="inline-field"><input id="property-name" data-id="${selectedFile.id}" value="${esc(propertyDrafts.get(selectedFile.id)??selectedFile.name)}" aria-label="项目名称" maxlength="160" autocomplete="off">${iconButton('check','应用名称','apply-name',`data-id="${selectedFile.id}" ${!propertyDrafts.has(selectedFile.id)?'disabled':''}`)}</div></label><p id="property-error" class="field-error" role="alert" hidden></p><div class="field"><span>位置</span><button class="path-value" data-action="move-selected">${I('folder')}<span>${esc(M.path(state,selectedFile.parent)||state.config.name)}</span></button></div></div><hr class="inspector-rule"><div class="property-group"><h3>文件信息</h3><dl><div class="kv-row"><dt>类型</dt><dd>${TYPES[selectedFile.type]}</dd></div><div class="kv-row"><dt>更新</dt><dd>${fmt(selectedFile.modified)}</dd></div><div class="kv-row"><dt>${selectedFile.type==='folder'?'子项目':'版本'}</dt><dd>${selectedFile.type==='folder'?M.children(state,selectedFile.id).length:selectedFile.versions.length}</dd></div></dl></div><hr class="inspector-rule"><div class="properties-actions">${iconButton('edit','重命名项目','rename',`data-id="${selectedFile.id}"`)}${iconButton('move','移动项目','move-selected')}${iconButton('copy','创建副本','duplicate')}${iconButton('trash','移入回收站','delete-selected')}</div>`);
}
function renderTable(){
 $('#main-content').innerHTML=`<section class="data-page"><header class="data-heading"><h1>列表标题</h1><div class="data-actions"><input id="list-search" aria-label="搜索条目" placeholder="搜索条目…" value="${esc(listQuery)}">${iconButton('plus','新增条目','new-row')}</div></header><div class="table-scroll"><table class="data-table"><colgroup><col><col class="kind-column"><col class="action-column"></colgroup><thead><tr><th id="name-sort" aria-sort="${listAscending?'ascending':'descending'}"><button data-action="sort-list">名称 ${I(listAscending?'down':'right')}</button></th><th>类型</th><th><span class="sr-only">操作</span></th></tr></thead><tbody id="table-rows"></tbody></table></div></section>`;
 paintTableRows();
}
function paintTableRows(){
 const tbody=$('#table-rows');if(!tbody)return;
 const rows=data().rows.filter(r=>r.name.toLowerCase().includes(listQuery.toLowerCase())).sort((a,b)=>(listAscending?1:-1)*a.name.localeCompare(b.name,'zh-CN'));
 $('#main-meta').textContent=listQuery?`${rows.length} / ${data().rows.length} 条记录`:`${data().rows.length} 条记录`;
 tbody.innerHTML=rows.map(r=>`<tr data-row="${r.id}" tabindex="0" aria-label="${esc(r.name)}"><td><span class="table-name">${I('file')}<span>${esc(r.name)}</span></span></td><td>${esc(r.kind)}</td><td>${iconButton('more','条目操作：'+r.name,'row-menu',`data-row-id="${r.id}"`)}</td></tr>`).join('')||'<tr><td colspan="3" class="table-empty">没有匹配条目</td></tr>';
}
function renderCanvas(){
 const c=$('#main-content'),saved=viewMemory.get(state.active);c.innerHTML=`<div class="canvas-view" id="canvas-view" tabindex="0" aria-label="关系画布；拖动空白平移"><div class="canvas-grid"></div><div class="canvas-world" id="canvas-world"></div><div class="canvas-label">画布标题</div><div class="canvas-tools">${iconButton('minus','缩小画布','zoom-out')}<span class="zoom-label" id="zoom-label"></span>${iconButton('plus','放大画布','zoom-in')}<span class="divider"></span>${iconButton('fit','适应画布','fit-canvas')}${iconButton('components','整理节点','arrange-graph')}${iconButton('plus','新增节点','new-graph')}</div></div>`;
 if(saved?.zoom){graphZoom=saved.zoom;graphOffset={...saved.offset};paintGraph();}else{paintGraph();requestAnimationFrame(()=>{if($('#canvas-view'))fitGraph();});}
}
function saveGraphView(){const old=viewMemory.get(state.active)||{};viewMemory.set(state.active,{...old,zoom:graphZoom,offset:{...graphOffset}});}
function zoomGraph(value,anchor=null){
 const v=$('#canvas-view');if(!v)return;const a=anchor||{x:v.clientWidth/2,y:v.clientHeight/2},z=Math.max(.2,Math.min(2,value));
 graphOffset={x:a.x-(a.x-graphOffset.x)*z/graphZoom,y:a.y-(a.y-graphOffset.y)*z/graphZoom};graphZoom=z;saveGraphView();paintGraph();
}
function arrangeGraph(){
 const ok=transact(s=>{const g=data(s).graph,edges=data(s).edges,incoming=new Set(edges.map(e=>e[1])),depth=new Map(),queue=[];for(const n of g)if(!incoming.has(n.id)){depth.set(n.id,0);queue.push(n.id);}if(!queue.length&&g[0]){depth.set(g[0].id,0);queue.push(g[0].id);}
  while(queue.length){const id=queue.shift();for(const e of edges.filter(e=>e[0]===id)){if(!depth.has(e[1])){depth.set(e[1],depth.get(id)+1);queue.push(e[1]);}}}
  const columns=new Map();for(const n of g){const d=Math.min(depth.get(n.id)||0,16),row=columns.get(d)||0;columns.set(d,row+1);n.x=64+d*240+Math.floor(row/40)*184;n.y=64+(row%40)*112;}return true;
 },'整理节点');if(ok){fitGraph();notify('节点已对齐；可撤销');}
}
function paintGraph(){
 const world=$('#canvas-world');if(!world)return;runtimeStats.graphPaints++;
 const graph=data().graph,byId=new Map(graph.map(x=>[x.id,x]));
 const key=JSON.stringify([graph.map(g=>[g.id,g.label]),data().edges]);
 if(world.dataset.graphKey!==key){runtimeStats.graphBuilds++;world.dataset.graphKey=key;
  world.innerHTML=`<svg class="graph-lines" aria-hidden="true"><defs><marker id="arrow-head" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto"><path d="M0 0 6 3 0 6Z"/></marker></defs>${data().edges.map((e,i)=>`<path data-edge="${i}" marker-end="url(#arrow-head)"/>`).join('')}</svg>`+graph.map(g=>`<button class="graph-node" data-graph="${g.id}" data-tip="${esc(g.label)}" aria-label="${esc(g.label)}，方向键可移动">${I('file')}<span>${esc(g.label)}</span></button>`).join('');
 }
 world.style.transform=`translate(${graphOffset.x}px,${graphOffset.y}px) scale(${graphZoom})`;
 world.style.width=Math.max(1400,...graph.map(n=>n.x+184))+'px';world.style.height=Math.max(1000,...graph.map(n=>n.y+96))+'px';
 for(const el of $$('[data-graph]',world)){const g=byId.get(el.dataset.graph);el.style.left=g.x+'px';el.style.top=g.y+'px';el.classList.toggle('selected',selectedGraph===g.id);el.setAttribute('aria-pressed',String(selectedGraph===g.id));el.classList.toggle('colliding',selectedGraph===g.id&&!!M.graphCollision(graph,g.id,g.x,g.y));}
 for(const el of $$('[data-edge]',world)){const [aId,bId]=data().edges[+el.dataset.edge],a=byId.get(aId),b=byId.get(bId);if(!a||!b)continue;const ax=a.x+152,ay=a.y+32,bx=b.x,by=b.y+32,m=(ax+bx)/2;el.setAttribute('d',`M${ax} ${ay} C${m} ${ay},${m} ${by},${bx-7} ${by}`);}
 $('#zoom-label').textContent=Math.round(graphZoom*100)+'%';const zi=$('[data-action="zoom-in"]'),zo=$('[data-action="zoom-out"]');if(zi)zi.disabled=graphZoom>=2;if(zo)zo.disabled=graphZoom<=.2;
}
function fitGraph(){const view=$('#canvas-view');if(!view||!data().graph.length)return;const minX=Math.min(...data().graph.map(n=>n.x)),minY=Math.min(...data().graph.map(n=>n.y)),maxX=Math.max(...data().graph.map(n=>n.x+152)),maxY=Math.max(...data().graph.map(n=>n.y+64));graphZoom=Math.min(1.25,(view.clientWidth-64)/(maxX-minX),(view.clientHeight-120)/(maxY-minY));graphZoom=Math.max(.2,graphZoom);graphOffset={x:(view.clientWidth-(maxX-minX)*graphZoom)/2-minX*graphZoom,y:(view.clientHeight-60-(maxY-minY)*graphZoom)/2-minY*graphZoom};saveGraphView();paintGraph();}
function previewHTML(){if(previewState==='loading')return `<div class="empty-view"><h2>加载状态占位</h2><div class="skeleton-stack" aria-hidden="true"><div class="skeleton"></div><div class="skeleton"></div><div class="skeleton"></div><div class="skeleton"></div></div><button class="text-button" data-action="exit-preview">取消预览</button></div>`;if(previewState==='error')return `<div class="empty-view">${I('warning')}<h2>无法读取内容</h2><p>这是错误状态示例，原内容没有丢失</p><button class="text-button" data-action="exit-preview">重新加载</button></div>`;return `<div class="empty-view">${I('file')}<h2>暂无内容</h2><button class="text-button" data-action="exit-preview">返回内容</button></div>`;}
function renderComponents(){const c=$('#main-content');$('#breadcrumb').textContent='组件参照';$('#view-tools').innerHTML=iconButton('more','状态预览','state-menu');$('#save-state').textContent='组件样板 · 非业务数据';$('#main-meta').textContent='DESIGN.md';c.innerHTML=`<div class="component-page"><h1>组件参照</h1><p class="hint-text">同一套尺寸、文字、图标与交互</p><section class="sample-section"><h2>按钮与图标</h2><div class="sample-row"><button class="text-button primary" data-action="sample-feedback">主要操作</button><button class="text-button" data-action="sample-feedback">次要操作</button><button class="text-button quiet" data-action="sample-feedback">普通操作</button><button class="text-button" disabled>不可用</button>${iconButton('more','操作菜单','workspace-menu')}</div></section><section class="sample-section"><h2>输入与选择</h2><div class="sample-row"><label class="field"><span>字段名称</span><input placeholder="输入内容" aria-label="组件字段"></label><label class="field"><span>选项名称</span><select aria-label="组件选项"><option>选项 01</option><option>选项 02</option></select></label></div><div class="sample-row"><label class="sample-check"><input type="checkbox">复选项</label><label class="sample-check"><input type="radio" name="sample-radio" checked>选项 01</label><label class="sample-check"><input type="radio" name="sample-radio">选项 02</label><button class="switch" role="switch" aria-checked="false" aria-label="示例开关" data-action="sample-switch"></button></div></section><section class="sample-section"><h2>分组切换</h2><div class="sample-row"><div class="sample-segment" role="group" aria-label="示例分段控件"><button data-action="sample-segment" aria-pressed="true">选项 01</button><button data-action="sample-segment" aria-pressed="false">选项 02</button><button data-action="sample-segment" aria-pressed="false">选项 03</button></div></div></section><section class="sample-section"><h2>状态与反馈</h2><div class="sample-row"><span class="sample-status">${I('info')}默认</span><span class="sample-status success">${I('check')}成功</span><span class="sample-status warning">${I('warning')}警告</span><span class="sample-status error">${I('warning')}错误</span></div></section><section class="sample-section"><h2>浮层与状态预览</h2><div class="sample-row"><button class="text-button" data-action="sample-dialog">打开对话框</button><button class="text-button" data-action="state-menu">预览状态${I('down')}</button></div></section></div>`;WBSelect.enhance(c);}
function hideMenus(restore=false){WBSelect.close(false);
 clearTimeout(menuHoverTimer);const hadMenus=menus.length>0,ref=menus[0]?.returnRef;
 for(const m of menus){if(m.parent||m.returnEl?.getAttribute('aria-haspopup')==='menu')m.returnEl?.setAttribute('aria-expanded','false');m.el.remove();}menus=[];
 if(restore&&hadMenus)restoreFocus(ref,true);
}
function closeSubmenu(model){
 const i=menus.indexOf(model);if(i<0)return;
 for(const m of menus.splice(i)){m.el.remove();m.returnEl?.setAttribute('aria-expanded','false');}
 if(model.parent){model.parent.el.hidden=false;restoreFocus(model.returnRef);}
}
function menuTab(ref,backward){
 hideMenus(true);const host=overlayHost(),items=$$('button,input,select,textarea,a[href],[tabindex="0"]',host).filter(el=>focusVisible(el)&&el.tabIndex>=0&&!el.closest('.menu'));
 const i=items.indexOf(document.activeElement);(items[(i+(backward?-1:1)+items.length)%items.length]||$('#main-content')).focus({preventScroll:true});
}
function openMenu(items,x,y,returnEl=null,parent=null,takeFocus=true){
 hideTip();clearTimeout(menuHoverTimer);
 if(!parent)hideMenus();else {const i=menus.indexOf(parent);for(const old of menus.splice(i+1)){old.el.remove();old.returnEl?.setAttribute('aria-expanded','false');}parent.el.hidden=false;}
 const el=document.createElement('div');el.className='menu popup-surface';el.setAttribute('role','menu');el.setAttribute('aria-label',parent?'子操作菜单':'操作菜单');el.tabIndex=-1;
 el.innerHTML=items.map((it,index)=>it.sep?'<div role="separator" class="menu-separator"></div>':`<button type="button" class="menu-item choice-row ${it.danger?'danger':''}" role="menuitem" aria-label="${esc(it.label)}" tabindex="-1" data-menu-index="${index}" ${it.disabled?'aria-disabled="true"':''} ${it.children?'aria-haspopup="menu" aria-expanded="false"':''}>${I(it.icon||'file')}<span class="label">${esc(it.label)}</span>${it.shortcut?'<span class="shortcut">'+esc(it.shortcut)+'</span>':''}${it.children?I('right','menu-arrow'):''}</button>`).join('');
 overlayHost().append(el);
 const pad=8,gap=4,w=el.offsetWidth;let left=x,top=y,drill=false;
 if(parent){const r=parent.el.getBoundingClientRect();if(r.right+gap+w<=innerWidth-pad){left=r.right+gap;el.dataset.side='right';}else if(r.left-gap-w>=pad){left=r.left-gap-w;el.dataset.side='left';}else {left=r.left;top=r.top;drill=true;el.classList.add('menu-drilldown');el.insertAdjacentHTML('afterbegin',`<button class="menu-item choice-row menu-back" type="button" role="menuitem" data-menu-back aria-label="返回上一级">${I('arrow')}<span class="label">返回</span></button><div class="menu-separator" role="separator"></div>`);parent.el.hidden=true;}returnEl?.setAttribute('aria-expanded','true');}
 // Drilldown adds a back row and a wider minimum; measure its final geometry, not the pre-drill width.
 const measuredWidth=el.offsetWidth,h=el.offsetHeight;el.style.left=Math.max(pad,Math.min(left,innerWidth-measuredWidth-pad))+'px';el.style.top=Math.max(pad,Math.min(top,innerHeight-h-pad))+'px';
 const model={el,items,returnEl,returnRef:focusRef(returnEl),parent,drill};menus.push(model);
 el.addEventListener('click',e=>{
  if(e.target.closest('[data-menu-back]')){closeSubmenu(model);return;}
  const button=e.target.closest('[data-menu-index]');if(!button)return;const it=items[+button.dataset.menuIndex];if(it.disabled)return;
  if(it.children){const r=button.getBoundingClientRect();openMenu(it.children,r.right+gap,r.top,button,model,true);return;}
  hideMenus(true);it.run?.();
 });
 el.addEventListener('pointerover',e=>{const b=e.target.closest('[data-menu-index]');if(!b||b.contains(e.relatedTarget))return;clearTimeout(menuHoverTimer);const it=items[+b.dataset.menuIndex];b.focus({preventScroll:true});
  if(it.children&&!it.disabled)menuHoverTimer=setTimeout(()=>{if(b.isConnected&&el.matches(':hover')){const r=b.getBoundingClientRect();openMenu(it.children,r.right+gap,r.top,b,model,false);}},220);
  else menuHoverTimer=setTimeout(()=>{const child=menus[menus.indexOf(model)+1];if(child&&el.matches(':hover'))closeSubmenu(child);},220);
 });
 el.addEventListener('pointerleave',()=>clearTimeout(menuHoverTimer));
 el.addEventListener('keydown',e=>{
  const opts=$$('button',el),idx=opts.indexOf(document.activeElement);
  if(['ArrowDown','ArrowUp','Home','End'].includes(e.key)){e.preventDefault();const next=e.key==='Home'?0:e.key==='End'?opts.length-1:(idx+(e.key==='ArrowDown'?1:-1)+opts.length)%opts.length;opts[next]?.focus();}
  else if(e.key==='ArrowRight'){const b=opts[idx],it=items[+b?.dataset.menuIndex];if(it?.children&&!it.disabled){e.preventDefault();const r=b.getBoundingClientRect();openMenu(it.children,r.right+gap,r.top,b,model);}}
  else if(e.key==='ArrowLeft'&&parent){e.preventDefault();closeSubmenu(model);}
  else if(e.key==='Escape'){e.preventDefault();e.stopPropagation();if(parent)closeSubmenu(model);else hideMenus(true);}
  else if(e.key==='Tab'){e.preventDefault();e.stopPropagation();menuTab(menus[0]?.returnRef,e.shiftKey);}
  else if(e.key.length===1&&!e.ctrlKey&&!e.metaKey){const start=idx+1,b=opts.slice(start).concat(opts.slice(0,start)).find(b=>b.textContent.trim().toLowerCase().startsWith(e.key.toLowerCase()));b?.focus();}
 });
 if(takeFocus)$('button',el)?.focus({preventScroll:true});return model;
}
function anchorMenu(items,button){button.setAttribute('aria-haspopup','menu');button.setAttribute('aria-expanded','true');const r=button.getBoundingClientRect();openMenu(items,r.left,r.bottom+5,button);}
const sep={sep:true};
function newItems(parent){return ['document','folder','table','canvas'].map(type=>({label:'新建'+TYPES[type]+'…',icon:ICONS[type],run:()=>createDialog(type,parent)}));}
function parentForCreate(){const target=selectedNode();return target?.type==='folder'?target.id:(target?.parent||'#');}
function rootItems(){return [...newItems('#'),sep,{label:'粘贴',icon:'paste',disabled:!clipboard,run:()=>paste('#')},{label:'折叠全部',icon:'collapse',run:()=>{state.openFolders=[];persist();renderTree();}}];}
function nodeItems(ids){ids=M.topSelection(state,ids);if(!ids.length)return rootItems();const f=M.node(state,ids[0]),one=ids.length===1;return actions(
 one&&{label:f.type==='folder'?'展开或收起':'打开',icon:f.type==='folder'?'folderOpen':'file',shortcut:'Enter',run:()=>openFile(f.id)},
 one&&f.type==='folder'&&{label:'新建',icon:'plus',children:newItems(f.id)},
 one&&{label:'重命名…',icon:'edit',shortcut:'F2',run:()=>renameDialog(f.id)},
 {label:'移动到…',icon:'move',run:()=>moveDialog(ids)},sep,
 {label:'剪贴板',icon:'copy',children:[{label:'复制',icon:'copy',shortcut:'Ctrl C',run:()=>setClipboard(ids,'copy')},{label:'剪切',icon:'cut',shortcut:'Ctrl X',run:()=>setClipboard(ids,'cut')},{label:'粘贴',icon:'paste',shortcut:'Ctrl V',disabled:!clipboard,run:()=>paste(f.type==='folder'?f.id:f.parent)}]},
 {label:'创建副本',icon:'copy',run:()=>duplicate(ids)},one&&{label:'复制路径',icon:'link',run:()=>copyPath(f.id)},sep,
 {label:'移入回收站',icon:'trash',shortcut:'Delete',danger:true,run:()=>deleteSelection(ids)});
}
function workspaceItems(){return [{label:'工作台设置…',icon:'settings',run:()=>settingsDialog()},{label:'导出',icon:'download',children:[{label:'导出 HTML 样本',icon:'file',run:downloadHTML},{label:'导出工作区 JSON',icon:'download',run:exportJSON},{label:'导出 Agent 填表说明',icon:'file',run:exportBrief}]},{label:'导入工作区…',icon:'upload',run:()=>$('#import-file').click()},sep,{label:'恢复默认布局',icon:'restore',run:resetLayout},{label:'预览状态',icon:'eye',children:stateItems()},sep,{label:'重置演示数据…',icon:'restore',run:resetDialog}];}
function stateItems(){return ['empty','loading','error'].map((s,i)=>({label:['空内容','加载占位','错误示例'][i],icon:['file','history','warning'][i],run:()=>{previewState=s;renderMain();}}));}
function panelItems(view){return [{label:'移至另一侧',icon:'swap',run:()=>swapPanels()},{label:'收起此侧栏',icon:'close',run:()=>hidePanel(view)},{label:'设置宽度…',icon:'move',run:()=>widthDialog(physicalSide(view))},sep,...(view==='explorer'?[{label:navMode==='files'?'打开回收站':'返回文件',icon:navMode==='files'?'trash':'files',run:()=>setNav(navMode==='files'?'trash':'files')},{label:'新建',icon:'plus',children:newItems(parentForCreate())}]:[{label:'查看属性',icon:'settings',run:()=>{inspectorTab='properties';renderInspector();}},{label:'查看版本',icon:'history',run:()=>{inspectorTab='history';renderInspector();}}])];}
function tabItems(id){return [{label:'关闭',icon:'close',run:()=>closeTab(id)},{label:'关闭其他标签',icon:'files',run:()=>{state.tabs=[id];state.active=id;persist();render();}},{label:'关闭全部标签',icon:'close',run:()=>{state.tabs=[];state.active=null;persist();render();}},sep,{label:'在文件树中定位',icon:'folder',run:()=>{setNav('files');expandAncestors(id);state.selected=[id];focusId=id;renderTree();showPanel('explorer');$(`[data-node="${id}"]`)?.focus();}}];}
function trashItems(entryId){return [{label:'恢复',icon:'restore',run:()=>restoreEntry(entryId)},{label:'永久删除…',icon:'trash',danger:true,run:()=>purgeDialog(entryId)}];}
function showDialog({title,description='',body='',submit='确定',danger=false,onSubmit=null,onOpen=null}){
 hideMenus();hideTip();const d=$('#modal');if(d.open)d.close();d.className='';settingsDirty=false;modalReturn=focusRef();
 d.innerHTML=`<form id="modal-form"><header class="dialog-head"><h2 id="modal-title">${esc(title)}</h2>${iconButton('close','关闭对话框','close-dialog')}</header><div class="dialog-body">${description?`<p class="dialog-description" id="modal-description">${esc(description)}</p>`:''}${body}<p class="dialog-error" id="dialog-error" role="alert" hidden></p></div><footer class="dialog-foot"><button type="button" class="text-button quiet" data-action="close-dialog">取消</button><button type="submit" class="text-button ${danger?'danger':'primary'}" id="modal-submit">${esc(submit)}</button></footer></form>`;
 const generation=++dialogGeneration;d.setAttribute('aria-labelledby','modal-title');if(description)d.setAttribute('aria-describedby','modal-description');else d.removeAttribute('aria-describedby');
 modalSubmit=onSubmit;d.setAttribute('aria-modal','true');WBSelect.enhance(d);d.showModal();
 if(!d.open||generation!==dialogGeneration)return;if(danger)$('[data-action="close-dialog"]',d).focus();else{
  const input=$$('input:not([hidden]),textarea,[role=combobox]',d).find(focusVisible);if(input){input.focus();input.select?.();}
 }onOpen?.();
}
function closeDialog(){hideMenus();hideTip();const d=$('#modal'),ref=modalReturn;dialogGeneration++;d.close();modalSubmit=null;settingsDirty=false;overlayHost().append($('#toast'));positionToast();restoreFocus(ref,true);}
function nameField(value,label='名称'){return `<label class="field"><span>${esc(label)}</span><input name="name" aria-label="${esc(label)}" value="${esc(value)}" maxlength="160" required autocomplete="off"></label>`;}
function createDialog(type='document',parent=parentForCreate()){const name=type==='folder'?'新文件夹':type==='table'?'新列表':type==='canvas'?'新画布':'未命名.md';showDialog({title:'新建'+TYPES[type],body:nameField(name),submit:'创建',onSubmit:form=>{let id;const ok=transact(s=>{id=M.create(s,parent,type,new FormData(form).get('name'));if(parent!=='#'&&!s.openFolders.includes(parent))s.openFolders.push(parent);s.selected=[id];return true;},'新建'+TYPES[type]);if(!ok)return false;if(type!=='folder')openFile(id);else {focusId=id;renderTree();}notify('已创建');return true;}});}
function renameDialog(id=selected()[0]){const f=M.node(state,id);if(!f)return;showDialog({title:'重命名',body:nameField(f.name),submit:'保存',onSubmit:form=>{const ok=transact(s=>{M.rename(s,id,new FormData(form).get('name'));return true;},'重命名');if(ok)notify('名称已更新');return !!ok;}});}
function moveDialog(ids=selected()){ids=M.topSelection(state,ids);if(!ids.length)return;const forbidden=new Set(ids.flatMap(id=>M.descendants(state,id))),folders=state.nodes.filter(n=>n.type==='folder'&&!forbidden.has(n.id));showDialog({title:'移动到',description:ids.length+' 个项目',body:`<label class="field"><span>目标文件夹</span><select name="parent" aria-label="目标文件夹"><option value="#">${esc(state.config.name)}（根目录）</option>${folders.map(f=>`<option value="${f.id}">${esc(M.path(state,f.id))}</option>`).join('')}</select></label>`,submit:'移动',onSubmit:form=>{const parent=new FormData(form).get('parent');const ok=transact(s=>{M.move(s,ids,parent);if(parent!=='#'&&!s.openFolders.includes(parent))s.openFolders.push(parent);return true;},'移动项目');if(ok)notify('已移动');return !!ok;}});}
function deleteSelection(ids=selected()){ids=M.topSelection(state,ids);if(!ids.length)return;const count=ids.reduce((a,id)=>a+M.descendants(state,id).length,0);function execute(){const ok=transact(s=>{M.remove(s,ids);return true;},'移入回收站');if(ok)notify(`${count} 项已移入回收站`,'info',{label:'撤销',run:undo});return !!ok;}
 if(count>1)showDialog({title:'移入回收站？',description:`将移动所选项目及其内容，共 ${count} 项。之后可以恢复。`,submit:'移入回收站',onSubmit:execute});else execute();}
function restoreEntry(entryId){let id;const ok=transact(s=>{id=M.restore(s,entryId);return true;},'恢复项目');if(ok)notify('已恢复；同名时自动保留两份');}
function purgeDialog(entryId){const e=state.trash.find(x=>x.id===entryId);if(!e)return;const root=e.items.find(x=>x.id===e.rootId);showDialog({title:'永久删除？',description:`“${root.name}”及其 ${e.items.length} 项内容将从此演示工作区永久移除，不能撤销。`,submit:'永久删除',danger:true,onSubmit:()=>{const ok=transact(s=>{s.trash=s.trash.filter(x=>x.id!==entryId);return true;},'永久删除');undoState=null;if(ok)notify('已永久删除');return !!ok;}});}
function duplicate(ids=selected()){const result=transact(s=>{const newIds=M.duplicate(s,ids);s.selected=newIds;return newIds;},'创建副本');if(result)notify('副本已创建');}
function setClipboard(ids,mode){clipboard={ids:M.topSelection(state,ids),mode};renderTree();notify(mode==='copy'?'已复制项目':'已剪切项目');}
function paste(parent=parentForCreate()){if(!clipboard)return;const available=clipboard.ids.filter(id=>M.node(state,id));if(!available.length)return notify('剪贴板中的项目已不存在','error');const mode=clipboard.mode;const ok=transact(s=>{const ids=mode==='cut'?M.move(s,available,parent):M.duplicate(s,available,parent);s.selected=ids;if(parent!=='#'&&!s.openFolders.includes(parent))s.openFolders.push(parent);return true;},'粘贴项目');if(ok){if(mode==='cut')clipboard=null;renderTree();notify('已粘贴');}}
async function copyPath(id){const text=M.path(state,id);try{await navigator.clipboard.writeText(text);notify('路径已复制');}catch(e){showDialog({title:'复制路径',body:`<label class="field"><span>路径</span><input aria-label="文件路径" value="${esc(text)}" readonly></label>`,submit:'完成',onSubmit:()=>true});}}
function saveDocument(){
 const f=n();if(!f||f.type!=='document')return;
 const report=()=>notify(storageProblem?'文档保留在当前会话 · '+storageProblem:storageAvailable?'文档已保存到本机':'文档已保存到本次会话',storageProblem?'error':'info');
 if(f.draft===null){if(storageProblem){persist();updateSaveState();report();}return;}
 const id=state.active,mode=editMode,ok=transact(s=>{M.save(s,id);return true;},'保存文档');editMode=mode;if(ok)report();
}
function viewVersion(id,index){const f=M.node(state,id),v=f?.versions[index];if(!v)return;const latest=index===f.versions.length-1;showDialog({title:`版本 ${v.number}`,description:fmt(v.time),body:`<pre>${esc(v.content||'[空内容]')}</pre>`,submit:latest?'关闭':'恢复为新版本',onSubmit:()=>{if(latest)return true;const ok=transact(s=>{M.restoreVersion(s,id,index);return true;},'恢复文档版本');if(ok)notify('旧内容已保存为一个新版本');return !!ok;}});}
function rowItems(id){const row=data().rows.find(r=>r.id===id);return [{label:'编辑…',icon:'edit',run:()=>rowDialog(row)},{label:'创建副本',icon:'copy',run:()=>transact(s=>{data(s).rows.push({...row,id:M.uid(),name:row.name+' 副本'});return true;},'复制条目')},sep,{label:'删除条目',icon:'trash',danger:true,run:()=>{transact(s=>{data(s).rows=data(s).rows.filter(r=>r.id!==id);return true;},'删除列表条目');notify('条目已删除','info',{label:'撤销',run:undo});}}];}
function rowDialog(row=null){showDialog({title:row?'编辑条目':'新增条目',body:nameField(row?.name||'新条目')+`<label class="field"><span>类型</span><select name="kind" aria-label="条目类型"><option ${row?.kind==='文本'?'selected':''}>文本</option><option ${row?.kind==='资料'?'selected':''}>资料</option></select></label>`,submit:'保存',onSubmit:form=>{const fd=new FormData(form),name=fd.get('name').trim();if(!name)throw new Error('名称不能为空');return !!transact(s=>{const r=row?data(s).rows.find(x=>x.id===row.id):{id:M.uid(),note:''};r.name=name;r.kind=fd.get('kind');if(!row)data(s).rows.push(r);return true;},row?'编辑条目':'新增条目');}});}
function graphDialog(id=null){const node=data().graph.find(x=>x.id===id);showDialog({title:node?'编辑节点':'新增节点',body:nameField(node?.label||'新节点','节点名称'),submit:'保存',onSubmit:form=>{const text=new FormData(form).get('name').trim();if(!text)throw new Error('名称不能为空');return !!transact(s=>{if(node)data(s).graph.find(x=>x.id===id).label=text;else{const num=data(s).graph.length,pos=M.freeGraphPosition(data(s).graph,null,64+(num%3)*208,80+Math.floor(num/3)*140);data(s).graph.push({id:M.uid(),label:text,...pos});}return true;},node?'编辑节点':'新增节点');}});}
function graphItems(id){return [{label:'编辑节点…',icon:'edit',run:()=>graphDialog(id)},{label:'移动到坐标…',icon:'move',run:()=>graphMoveDialog(id)},sep,{label:'删除节点',icon:'trash',danger:true,run:()=>{transact(s=>{data(s).graph=data(s).graph.filter(n=>n.id!==id);data(s).edges=data(s).edges.filter(e=>!e.includes(id));return true;},'删除节点');notify('节点已删除','info',{label:'撤销',run:undo});}}];}
function graphMoveDialog(id){const node=data().graph.find(x=>x.id===id);if(!node)return;showDialog({title:'移动节点',body:`<div class="settings-grid"><label class="field"><span>X</span><input name="x" type="number" aria-label="X 坐标" min="0" max="5000" value="${node.x}" required></label><label class="field"><span>Y</span><input name="y" type="number" aria-label="Y 坐标" min="0" max="5000" value="${node.y}" required></label></div>`,submit:'移动',onSubmit:form=>{const fd=new FormData(form);return !!transact(s=>{return M.moveGraph(s,s.active,id,+fd.get('x'),+fd.get('y'));},'移动节点');}});}
function settingsDialog(options={}){
 const c=state.config,section=options.section||settingsSection;
 const choice=(key,label,values)=>{if(!values.some(([v])=>String(v)===String(c[key])))values=[...values,[c[key],String(c[key])+" px · 当前值"]];return `<label class="setting-row"><span>${label}</span><select name="${key}" aria-label="${label}">${values.map(([v,text])=>`<option value="${v}" ${String(c[key])===String(v)?'selected':''}>${text}</option>`).join('')}</select></label>`;};
 const width=(key,label)=>`<label class="setting-row"><span>${label}</span><span class="unit-input"><input name="${key}" type="number" aria-label="${label}" min="216" max="400" value="${c[key]}" required><span>px</span></span></label>`;
 showDialog({title:'工作台设置',body:`
 <div class="settings-tabs" role="tablist" aria-label="设置分类">${[['appearance','外观'],['layout','布局'],['workspace','工作区']].map(([k,l])=>`<button type="button" role="tab" id="settings-tab-${k}" data-action="settings-section" data-section="${k}" aria-controls="settings-${k}">${l}</button>`).join('')}</div>
 <section id="settings-appearance" class="settings-section" role="tabpanel" aria-labelledby="settings-tab-appearance">
 <div class="settings-section-heading"><h3>外观</h3><p>颜色与密度遵循同一套组件规格。</p></div>
 ${choice('theme','主题',[['dark','深色'],['light','浅色']])}
 ${choice('density','密度',[['comfortable','舒适'],['compact','紧凑']])}
 ${choice('gap','面板间距',[[8,'8 px'],[12,'12 px'],[16,'16 px · 默认'],[24,'24 px']])}
 ${choice('radius','面板圆角',[[4,'4 px'],[8,'8 px · 默认'],[12,'12 px']])}
 </section>
 <section id="settings-layout" class="settings-section" role="tabpanel" aria-labelledby="settings-tab-layout" hidden>
 <div class="settings-section-heading"><h3>布局</h3><p>宽度为偏好值；空间不足时自动缩窄。</p></div>
 ${choice('leftView','左侧视图',[['explorer','文件资源'],['inspector','检查器']])}
 ${width('leftWidth','左侧栏宽度')}${width('rightWidth','右侧栏宽度')}
 ${choice('hideLeft','左侧栏',[['false','显示'],['true','收起']])}${choice('hideRight','右侧栏',[['false','显示'],['true','收起']])}
 <div class="settings-subactions"><button type="button" class="text-button quiet" data-action="settings-reset-layout">恢复默认布局</button></div>
 </section>
 <section id="settings-workspace" class="settings-section" role="tabpanel" aria-labelledby="settings-tab-workspace" hidden>
 <div class="settings-section-heading"><h3>工作区</h3><p>本地演示数据，不连接系统文件。</p></div>
 <label class="setting-row"><span>工作区名称</span><input name="name" aria-label="工作区名称" maxlength="40" value="${esc(c.name)}" required></label>
 <div class="settings-subgroup"><h3>备份与模板</h3><p>导出使用已应用的设置。</p><div class="settings-actions">
 <button type="button" class="text-button" data-action="settings-export-json">${I('download')}导出 JSON</button><button type="button" class="text-button" data-action="settings-import">${I('upload')}导入 JSON</button>
 <button type="button" class="text-button" data-action="settings-export-html">HTML 样本</button><button type="button" class="text-button" data-action="settings-export-brief">Agent 说明</button></div></div>
 <div class="settings-subgroup danger-group"><button type="button" class="text-button quiet danger" data-action="settings-reset">重置演示数据…</button></div>
 </section>`,submit:'应用设置',onSubmit:form=>{
  const fd=new FormData(form),patch={name:String(fd.get('name')).trim(),theme:fd.get('theme'),density:fd.get('density'),gap:+fd.get('gap'),radius:+fd.get('radius'),leftView:fd.get('leftView'),leftWidth:+fd.get('leftWidth'),rightWidth:+fd.get('rightWidth'),hideLeft:fd.get('hideLeft')==='true',hideRight:fd.get('hideRight')==='true'};
  try{applyConfig(patch);notify('设置已应用');return true;}catch(e){
   if(!patch.name||patch.name.length>40)switchSettings('workspace');else if([patch.leftWidth,patch.rightWidth].some(v=>v<216||v>400||!Number.isFinite(v)))switchSettings('layout');throw e;
  }
 },onOpen:()=>{switchSettings(section,false);if(options.focus){const input=$(`[name="${options.focus}"]`,$('#modal'));if(focusVisible(input))input.focus();}}});
 $('#modal').classList.add('settings-modal');$('#modal-form').noValidate=true;
 $('.dialog-foot',$('#modal')).insertAdjacentHTML('afterbegin','<span id="settings-status" class="settings-status" role="status">未更改</span>');
 switchSettings(section,false);refreshSettingsDirty();
 const initial=options.focus?$(`[name="${options.focus}"]`,dSafe()):$$('input:not([hidden]),[role=combobox]',$('#settings-'+settingsSection)).find(focusVisible);if(initial)initial.focus({preventScroll:true});
}
function dSafe(){return $('#modal');}
function widthDialog(side){settingsDialog({section:'layout',focus:side==='left'?'leftWidth':'rightWidth'});}
function helpDialog(){showDialog({title:'操作帮助',body:`${[['搜索文件与命令','Ctrl K / Ctrl P'],['文件树上下导航','↑ / ↓'],['展开或收起文件夹','→ / ←'],['打开文件','Enter'],['项目操作菜单','右键 / Shift F10 / …'],['重命名','F2'],['复制 / 剪切 / 粘贴','Ctrl C / X / V'],['保存文档','Ctrl S'],['撤销上一次结构操作','Ctrl Z（非编辑框）'],['调整侧栏宽度','拖动分隔条 / 方向键'],['迁移侧栏','拖动标题握柄 / ⇄ 按钮']].map(x=>`<div class="shortcut-row"><span>${x[0]}</span><kbd class="key">${x[1]}</kbd></div>`).join('')}<hr class="inspector-rule"><p class="hint-text">仅操作浏览器内的演示数据，不连接系统文件夹、账户或模型服务。文件与版本可导出备份。</p>`,submit:'知道了',onSubmit:()=>true});}
function resetLayout(){state.config={...state.config,leftWidth:WBTokens.geometry.leftWidth,rightWidth:WBTokens.geometry.rightWidth,leftView:'explorer',hideLeft:false,hideRight:false};if(drawerView)closeDrawer();persist();applyLayout();notify('布局已恢复');}
function resetDialog(){showDialog({title:'重置此演示工作区？',description:'将清除当前演示中的文件、版本、回收站及配置。不会访问或删除系统文件。请先导出需要保留的数据。',submit:'重置演示',danger:true,onSubmit:()=>{state=M.createSeed();undoState=null;undoAfter=null;clipboard=null;query='';editMode=false;activity='files';surface='files';navMode='files';storageLocked=false;storageProblem='';persist();render();notify('已恢复占位数据');return true;}});}
function download(name,text,type='text/plain;charset=utf-8'){const url=URL.createObjectURL(new Blob([text],{type})),a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);}
function exportJSON(){if(persistPending)persist();download('workspace.json',JSON.stringify(state,null,2),'application/json');notify('已生成工作区文件');}
function exportBrief(){const c=state.config;download('PROJECT-UI.md',`# 项目 UI 配置\n\n- 工作区：${c.name}\n- 参照：AIALRA Workbench v${WBTokens.version} / DESIGN.md\n- 主题：${c.theme}\n- 密度：${c.density}\n- 面板间距：${c.gap} CSS px\n- 面板圆角：${c.radius} CSS px\n- 左侧视图：${c.leftView}\n- 左／右宽度：${c.leftWidth} / ${c.rightWidth} CSS px\n- 主内容模式：文档、列表、画布\n- 本次业务要求：[填写]\n- 已认可方向：v2 黑白灰工作台；本次业务页细节：[填写]\n- 项目例外：[填写]\n- 接入组件：[复用当前项目]\n\n本文件记录具体配置，不复制 DESIGN.md 的规则正文。v2 风格方向已被认可；导出的具体配置与业务功能仍需实际验收。\n`,'text/markdown;charset=utf-8');}
function makeHTML(){const js=$('#app-code').textContent,css=$('#design-style').textContent,serialized=JSON.stringify(state).replace(/</g,'\\u003c');const closeScript='</scr'+'ipt>';return '<!doctype html><html lang="zh-CN" data-theme="dark"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+esc(state.config.name)+'</title><style id="design-style">'+css+'</style></head><body>'+scaffold()+'<script id="initial-state" type="application/json">'+serialized+closeScript+'<script id="app-code">'+js+closeScript+'</body></html>';}
function downloadHTML(){if(persistPending)persist();download('Workbench-'+state.config.name.replace(/[^\p{L}\p{N}_-]+/gu,'-')+'.html',makeHTML(),'text/html;charset=utf-8');notify('已生成独立 HTML 样本');}
function scaffold(){return '<div id="app"></div><dialog id="modal"></dialog><dialog id="drawer"></dialog><dialog id="palette" aria-label="搜索文件与命令"><div class="palette-search">'+I('search')+'<input id="command-input" role="combobox" aria-label="搜索文件与命令" aria-autocomplete="list" aria-expanded="true" aria-controls="command-results" autocomplete="off" placeholder="输入文件名或命令…"><button class="icon-button" id="palette-clear" data-action="clear-palette" aria-label="清除搜索" data-tip="清除搜索文字" hidden>'+I('close')+'</button><button class="icon-button" data-action="close-palette" aria-label="关闭命令面板" data-tip="关闭命令面板">'+I('close')+'</button></div><div id="command-results" role="listbox"></div><div class="palette-foot"><span>↑ ↓ 选择 · Enter 执行</span><span id="palette-count" role="status" aria-live="polite"></span></div></dialog><div id="toast" class="toast" hidden></div><div id="tooltip" class="tooltip" role="tooltip" hidden></div><input id="import-file" type="file" accept="application/json,.json" hidden>';} 

// Every menu/button/shortcut routes to the same command and model operations.
let paletteEntries=[],paletteIndex=0,paletteReturn=null,commandCache=null,paletteNodes=[],lastPaletteIndex=-1;
function setNav(mode){
 if(!['files','search','trash','components'].includes(mode))return;
 const previousSurface=surface,hadPreview=!!previewState;rememberView();WBSelect.close();hideMenus();hideTip();
 activity=mode;navMode=mode==='trash'?'trash':'files';surface=mode==='components'?'components':'files';previewState='';
 updateActivity();renderTree();if(previousSurface!==surface||hadPreview){renderTabs();renderMain();}renderStatus();if(mode!=='components')showPanel('explorer');
}
function commandEntries(){if(commandCache?.nodes===state.nodes&&commandCache.name===state.config.name)return commandCache.entries;
 runtimeStats.commandIndexBuilds++;const index=getTreeIndex();const entries=[...state.nodes.filter(n=>n.type!=='folder').map(f=>({label:f.name,detail:index.paths.get(f.id),icon:ICONS[f.type],run:()=>openFile(f.id)})),{label:'新建文档',icon:'plus',run:()=>createDialog('document')},{label:'新建文件夹',icon:'folder',run:()=>createDialog('folder')},{label:'打开回收站',icon:'trash',run:()=>setNav('trash')},{label:'组件参照',icon:'components',run:()=>setNav('components')},{label:'工作台设置',icon:'settings',run:settingsDialog},{label:'交换左右侧栏',icon:'swap',run:()=>swapPanels()},{label:'恢复默认布局',icon:'restore',run:resetLayout},{label:'导出 HTML 样本',icon:'download',run:downloadHTML},{label:'导出工作区 JSON',icon:'download',run:exportJSON},{label:'导出 Agent 填表说明',icon:'file',run:exportBrief},{label:'导入工作区 JSON',icon:'upload',run:()=>$('#import-file').click()},{label:'撤销上次结构操作',icon:'restore',run:undo},{label:'操作帮助',icon:'help',run:helpDialog}];for(const e of entries)e.search=(e.label+' '+(e.detail||'')).toLocaleLowerCase();commandCache={nodes:state.nodes,name:state.config.name,entries};return entries;}
function openPalette(){hideMenus();hideTip();paletteReturn=focusRef();$('#palette').setAttribute('aria-modal','true');$('#palette').showModal();$('#command-input').value='';paletteIndex=0;filterPalette();$('#command-input').focus();}
function closePalette(){WBSelect.close(false);hideTip();const d=$('#palette');if(d.open)d.close();overlayHost().append($('#toast'));positionToast();restoreFocus(paletteReturn,true);}
function filterPalette(){runtimeStats.paletteBuilds++;const q=$('#command-input').value.trim().toLowerCase();paletteEntries=commandEntries().filter(e=>e.search.includes(q)).slice(0,50);paletteIndex=Math.max(0,Math.min(paletteIndex,paletteEntries.length-1));$('#command-results').innerHTML=paletteEntries.map((e,i)=>`<button class="command-item" role="option" id="cmd-${i}" data-command="${i}" aria-selected="${i===paletteIndex}" tabindex="-1">${I(e.icon)}<span class="label">${esc(e.label)}${e.detail?'<small>'+esc(e.detail)+'</small>':''}</span></button>`).join('')||'<div class="no-results">没有匹配结果</div>';paletteNodes=$$('[data-command]',$('#command-results'));lastPaletteIndex=-1;updatePaletteSelection();
 $('#palette-count').textContent=paletteEntries.length===50?'前 50 项 · 输入以筛选':paletteEntries.length+' 项结果';
 $('#palette-clear').hidden=!$('#command-input').value;
}
function updatePaletteSelection(){
 if(paletteNodes[lastPaletteIndex])paletteNodes[lastPaletteIndex].setAttribute('aria-selected','false');
 const row=paletteNodes[paletteIndex];if(row)row.setAttribute('aria-selected','true');lastPaletteIndex=paletteIndex;
 $('#command-input').setAttribute('aria-activedescendant',row?.id||'');row?.scrollIntoView({block:'nearest'});
}
function executePalette(index){const entry=paletteEntries[index];if(!entry)return;closePalette();entry.run();}
function hideTip(){clearTimeout(tooltipTimer);clearTimeout(tooltipCloseTimer);const tip=$('#tooltip');if(tip)tip.hidden=true;$$('[aria-describedby="tooltip"]').forEach(x=>x.removeAttribute('aria-describedby'));tooltipOwner=null;}
function deferHideTip(){clearTimeout(tooltipCloseTimer);tooltipCloseTimer=setTimeout(()=>{const tip=$('#tooltip');if(!tip?.matches(':hover')&&!tooltipOwner?.matches(':hover')&&document.activeElement!==tooltipOwner)hideTip();},130);}
function requestTip(button){
 if(!button?.dataset.tip||menus.length||WBSelect.isOpen()||matchMedia('(pointer:coarse)').matches)return;
 if(button===tooltipOwner&&!$('#tooltip').hidden){clearTimeout(tooltipCloseTimer);return;}
 hideTip();tooltipOwner=button;
 tooltipTimer=setTimeout(()=>{if(!focusVisible(button))return;const tip=$('#tooltip');overlayHost().append(tip);tip.textContent=button.dataset.tip;tip.hidden=false;const r=button.getBoundingClientRect(),tw=tip.offsetWidth,th=tip.offsetHeight;
 tip.style.left=Math.max(8,Math.min(r.left+(r.width-tw)/2,innerWidth-tw-8))+'px';tip.style.top=(r.bottom+8+th<innerHeight-8?r.bottom+8:Math.max(8,r.top-th-8))+'px';button.setAttribute('aria-describedby','tooltip');},420);
}
function focusTree(id){if(!M.node(state,id))return;focusId=id;if(!treeDom.get(id)?.isConnected)renderTree();else syncTreeSelection();const row=$(`[data-node="${id}"]`);row?.focus({preventScroll:true});row?.scrollIntoView({block:'nearest'});row?.querySelector(".tree-name")?.scrollIntoView({block:'nearest',inline:'nearest'});}
function commitProperty(input){
 const f=M.node(state,input?.dataset.id);if(!f)return;
 if(input.value===f.name){propertyDrafts.delete(f.id);return;}
 try{const draft=M.clone(state);M.rename(draft,f.id,input.value);M.validate(draft);}catch(err){input.setAttribute('aria-invalid','true');input.setAttribute('aria-describedby','property-error');$('#property-error').textContent=err.message;$('#property-error').hidden=false;return;}
 const ok=transact(s=>{M.rename(s,f.id,input.value);return true;},'修改名称');if(ok){propertyDrafts.delete(f.id);renderInspector();notify('名称已更新');$('#property-name')?.focus({preventScroll:true});}
}
function previewContext(e){const target=e.target.closest('[data-node],[data-tab],[data-trash],[data-row],[data-graph]');if(target?.dataset.node){const id=target.dataset.node;if(!selected().includes(id))selectNode(id);focusId=id;return {items:nodeItems(selected()),el:$(`[data-node="${id}"]`)};}if(target?.dataset.tab)return {items:tabItems(target.dataset.tab),el:target};if(target?.dataset.trash)return {items:trashItems(target.dataset.trash),el:target};if(target?.dataset.row)return {items:rowItems(target.dataset.row),el:target};if(target?.dataset.graph){selectedGraph=target.dataset.graph;$$('[data-graph]').forEach(el=>{el.classList.toggle('selected',el.dataset.graph===selectedGraph);el.setAttribute('aria-pressed',String(el.dataset.graph===selectedGraph));});return {items:graphItems(target.dataset.graph),el:target};}if(e.target.closest('#canvas-view')&&!e.target.closest('.canvas-tools'))return {items:[{label:'新增节点…',icon:'plus',run:()=>graphDialog()},{label:'整理节点',icon:'components',run:arrangeGraph},{label:'适应画布',icon:'fit',run:fitGraph}],el:$('#canvas-view')};if(e.target.closest('#tree-scroll'))return {items:rootItems(),el:$('#tree-scroll')};return null;}
function dispatch(button,e){const a=button.dataset.action,id=button.dataset.id,view=button.dataset.view;hideTip();switch(a){
case 'clear-tree-search':clearSearch('tree');break;case 'clear-palette':clearSearch('palette');break;case 'palette':openPalette();break;case 'close-palette':closePalette();break;
case 'nav-files':setNav('files');break;case 'nav-search':setNav('search');$('#tree-search').focus();break;case 'nav-trash':setNav('trash');break;
case 'components':setNav('components');break;case 'close-components':setNav('files');break;
case 'theme':applyConfig({theme:state.config.theme==='dark'?'light':'dark'});break;
case 'toggle-left':toggleSide('left');break;case 'toggle-right':toggleSide('right');break;
case 'settings':settingsDialog();break;case 'settings-section':switchSettings(button.dataset.section);break;case 'settings-export-json':exportJSON();break;case 'settings-export-html':downloadHTML();break;case 'settings-export-brief':exportBrief();break;case 'settings-import':$('#import-file').click();break;case 'settings-reset':resetDialog();break;case 'settings-reset-layout':stageDefaultLayout();break;case 'help':helpDialog();break;
case 'workspace-menu':anchorMenu(workspaceItems(),button);break;case 'panel-menu':anchorMenu(panelItems(view),button);break;case 'hide-panel':hidePanel(view);break;case 'swap-panels':swapPanels();break;
case 'tree-new':anchorMenu(rootItems(),button);break;case 'collapse-folders':state.openFolders=[];renderTree();scheduleViewPersist();break;case 'create-document':createDialog('document');break;
case 'toggle-folder':if(M.node(state,id)?.type==='folder')toggleFolder(id);break;
case 'node-menu':if(!selected().includes(id))selectNode(id);anchorMenu(nodeItems(selected()),$(`[data-node="${id}"] .row-more`)||button);break;
case 'open':openFile(id);break;case 'close-tab':closeTab(id);break;case 'tabs-menu':anchorMenu(state.active?tabItems(state.active):[{label:'新建文档…',icon:'plus',run:()=>createDialog('document')}],button);break;
case 'preview':editMode=false;renderMain();break;case 'edit':editMode=true;renderMain();$('#document-editor')?.focus();break;case 'save':saveDocument();break;
case 'active-menu':anchorMenu(n()?nodeItems([n().id]):rootItems(),button);break;
case 'inspector-properties':inspectorTab='properties';renderInspector();$('#inspector-tab-properties').focus({preventScroll:true});break;case 'inspector-history':inspectorTab='history';renderInspector();$('#inspector-tab-history').focus({preventScroll:true});break;case 'inspector-tab':inspectorTab=button.dataset.tab;renderInspector();break;
case 'apply-name':commitProperty($('#property-name'));break;
case 'rename':renameDialog(id||selected()[0]);break;case 'move-selected':moveDialog();break;case 'delete-selected':deleteSelection();break;case 'duplicate':duplicate();break;
case 'restore':restoreEntry(button.dataset.entry);break;case 'trash-menu':anchorMenu(trashItems(button.dataset.entry),button);break;case 'view-version':viewVersion(id,+button.dataset.version);break;
case 'sort-list':{const ref=focusRef();listAscending=!listAscending;renderTable();restoreFocus(ref);break;}case 'new-row':rowDialog();break;case 'row-menu':anchorMenu(rowItems(button.dataset.rowId),button);break;
case 'zoom-in':zoomGraph(graphZoom+.1);break;case 'zoom-out':zoomGraph(graphZoom-.1);break;case 'arrange-graph':arrangeGraph();break;case 'fit-canvas':fitGraph();break;case 'new-graph':graphDialog();break;
case 'state-menu':anchorMenu(stateItems(),button);break;case 'exit-preview':previewState='';renderMain();break;
case 'sample-feedback':notify('操作已接收 · 组件演示');break;case 'sample-switch':button.setAttribute('aria-checked',String(button.getAttribute('aria-checked')!=='true'));break;
case 'sample-segment':for(const b of $$('button',button.parentElement))b.setAttribute('aria-pressed',String(b===button));break;
case 'sample-dialog':showDialog({title:'对话框标题',body:nameField('','字段名称'),submit:'保存',onSubmit:()=>{notify('示例已提交');return true;}});break;
case 'close-dialog':closeDialog();break;case 'close-toast':$('#toast').hidden=true;break;
}}
// Input changes keep the editor node and caret intact. Drafts persist without claiming a saved revision.
function clearSearch(kind){
 if(kind==='tree'){queueTreeFilter.cancel();query='';$('#tree-search').value='';$('#tree-clear').hidden=true;renderTree();$('#tree-search').focus();}
 else if(kind==='palette'){$('#command-input').value='';paletteIndex=0;filterPalette();$('#command-input').focus();}
 else{listQuery='';const input=$('#list-search');if(input){input.value='';paintTableRows();input.focus();}}
}
function handleInput(e){
 const el=e.target;
 if(el.closest('.settings-modal'))refreshSettingsDirty();
 if(el.id==='property-name'){propertyDrafts.set(el.dataset.id,el.value);el.removeAttribute('aria-invalid');$('#property-error').hidden=true;const b=$('[data-action="apply-name"]');if(b)b.disabled=el.value===M.node(state,el.dataset.id)?.name;}
 else if(el.id==='tree-search'){query=el.value;$('#tree-clear').hidden=!query;if(!e.isComposing)queueTreeFilter();}
 else if(el.id==='document-editor'){const f=n();if(f){f.draft=el.value;schedulePersist();updateDirtyTab(f);updateSaveState();}}
 else if(el.id==='list-search'){listQuery=el.value;if(!e.isComposing)paintTableRows();}
 else if(el.id==='command-input'&&!e.isComposing){paletteIndex=0;filterPalette();}
}
function onKey(e){if(activeCancel){if(e.key==='Escape'){e.preventDefault();activeCancel();}return;}if(e.isComposing||e.keyCode===229)return;const el=e.target,typing=!!el.closest('input,textarea,select,[role=combobox],[contenteditable="true"]');
if(e.key==='Escape'&&((el.id==='tree-search'&&query)||(el.id==='list-search'&&listQuery))){e.preventDefault();e.stopPropagation();clearSearch(el.id==='tree-search'?'tree':'list');return;}
if(el.closest('.settings-tabs')&&['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){e.preventDefault();const items=$$('[role=tab]',el.closest('.settings-tabs')),i=items.indexOf(el),j=e.key==='Home'?0:e.key==='End'?items.length-1:(i+(e.key==='ArrowRight'?1:-1)+items.length)%items.length;switchSettings(items[j].dataset.section);return;}
if(el.id==='command-input'){if(['ArrowDown','ArrowUp'].includes(e.key)){e.preventDefault();paletteIndex=(paletteIndex+(e.key==='ArrowDown'?1:-1)+paletteEntries.length)%Math.max(1,paletteEntries.length);updatePaletteSelection();}else if(e.key==='Enter'){e.preventDefault();executePalette(paletteIndex);}return;}
if(e.key==='Escape')hideTip();if(menus.length)return;if($('#modal').open||$('#palette').open)return;
if(el.matches('.activity-rail [data-nav]')&&['ArrowUp','ArrowDown','Home','End'].includes(e.key)){
 e.preventDefault();const items=$$('.activity-rail [data-nav]'),i=items.indexOf(el);
 const j=e.key==='Home'?0:e.key==='End'?items.length-1:(i+(e.key==='ArrowDown'?1:-1)+items.length)%items.length;
 items.forEach((b,index)=>b.tabIndex=index===j?0:-1);items[j]?.focus({preventScroll:true});return;
}
if((e.ctrlKey||e.metaKey)&&['k','p'].includes(e.key.toLowerCase())){e.preventDefault();openPalette();return;}
if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s'){e.preventDefault();saveDocument();return;}
if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='b'&&!typing){e.preventDefault();toggleSide(e.shiftKey?'right':'left');return;}
if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z'&&!typing){e.preventDefault();undo();return;}
const tree=el.closest('[data-node]'),gr=el.closest('[data-graph]');if(el.matches('[data-row]')&&e.key==='Enter'){e.preventDefault();rowDialog(data().rows.find(r=>r.id===el.dataset.row));return;}
if((e.shiftKey&&e.key==='F10')||e.key==='ContextMenu'){const ctx=previewContext(e);if(ctx){e.preventDefault();const r=ctx.el.getBoundingClientRect();openMenu(ctx.items,r.left+24,r.top+12,ctx.el);}return;}
if(tree&&!typing){const id=tree.dataset.node,node=M.node(state,id),rows=visibleRows(),i=rows.findIndex(r=>r.node.id===id);let target;
if(e.key==='ArrowDown')target=rows[Math.min(rows.length-1,i+1)]?.node.id;else if(e.key==='ArrowUp')target=rows[Math.max(0,i-1)]?.node.id;else if(e.key==='Home')target=rows[0]?.node.id;else if(e.key==='End')target=rows.at(-1)?.node.id;
else if(e.key==='ArrowRight'){if(node.type==='folder'){if(!state.openFolders.includes(id))toggleFolder(id);else target=M.children(state,id)[0]?.id;}}else if(e.key==='ArrowLeft'){if(node.type==='folder'&&state.openFolders.includes(id))toggleFolder(id);else if(node.parent!=='#')target=node.parent;}
else if(e.key==='Enter'){openFile(id);}else if(e.key===' '){selectNode(id,{ctrlKey:e.ctrlKey||e.metaKey,shiftKey:e.shiftKey});}else if(e.key==='F2'){renameDialog(id);}else if(e.key==='Delete'){deleteSelection(selected().includes(id)?selected():[id]);}else if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='a'){state.selected=rows.map(r=>r.node.id);renderTree();renderInspector();focusTree(id);}else if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='c')setClipboard(selected().includes(id)?selected():[id],'copy');else if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='x')setClipboard(selected().includes(id)?selected():[id],'cut');else if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='v')paste(node.type==='folder'?id:node.parent);else if(e.key.length===1&&!e.ctrlKey&&!e.metaKey&&!e.altKey){treeTypeahead(e.key);return;}else return;
e.preventDefault();if(target){if(e.shiftKey){if(!selectionAnchor)selectionAnchor=id;selectNode(target,{shiftKey:true});}focusTree(target);}return;}
if(gr){const id=gr.dataset.graph;if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();const delta=e.shiftKey?32:8;transact(s=>{const g=data(s).graph.find(x=>x.id===id);return M.moveGraph(s,s.active,id,Math.max(0,Math.min(5000,g.x+(e.key==='ArrowLeft'?-delta:e.key==='ArrowRight'?delta:0))),Math.max(0,Math.min(5000,g.y+(e.key==='ArrowUp'?-delta:e.key==='ArrowDown'?delta:0))));},'键盘移动节点');$(`[data-graph="${id}"]`)?.focus();}else if(e.key==='Enter'||e.key==='F2'){e.preventDefault();graphDialog(id);}return;}
if(el.getAttribute('role')==='tab'&&['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){const list=el.closest('[role="tablist"]');if(!list)return;const items=$$('[role="tab"]',list);const i=items.indexOf(el),next=e.key==='Home'?0:e.key==='End'?items.length-1:(i+(e.key==='ArrowRight'?1:-1)+items.length)%items.length;e.preventDefault();items[next]?.click();const current=$$('[role="tab"]',document).find(x=>x.getAttribute('aria-selected')==='true'&&x.closest('[role="tablist"]')?.id===list.id);current?.focus();}
}
function resizeSide(side,next){
 const key=side==='left'?'leftWidth':'rightWidth',otherSide=side==='left'?'right':'left',oppositeVisible=!$('#'+otherSide+'-slot').hidden;
 const other=oppositeVisible?$('#'+otherSide+'-slot').getBoundingClientRect().width:0;
 const max=Math.max(216,Math.min(400,$('#layout').clientWidth-(oppositeVisible?other+state.config.gap:0)-state.config.gap-WBTokens.geometry.mainMin));
 if(oppositeVisible)state.config[otherSide+'Width']=Math.round(other);
 state.config[key]=Math.round(Math.max(216,Math.min(max,next)));applyLayout();
}
function installResize(el,side){
 el.addEventListener('pointerdown',e=>{if(e.button!==0)return;e.preventDefault();hideMenus();hideTip();const x=e.clientX,before={leftWidth:state.config.leftWidth,rightWidth:state.config.rightWidth},start=$('#'+side+'-slot').getBoundingClientRect().width;
 el.setPointerCapture(e.pointerId);document.body.classList.add('resizing');
 const task=frameTask(clientX=>resizeSide(side,start+(clientX-x)*(side==='left'?1:-1))),move=ev=>task(ev.clientX);
 const clean=()=>{task.cancel();el.removeEventListener('pointermove',move);el.removeEventListener('pointerup',up);el.removeEventListener('pointercancel',cancel);document.body.classList.remove('resizing');if(el.hasPointerCapture(e.pointerId))el.releasePointerCapture(e.pointerId);activeCancel=null;};
 const up=()=>{task.flush();clean();persist();},cancel=()=>{Object.assign(state.config,before);clean();applyLayout();};
 activeCancel=cancel;el.addEventListener('pointermove',move);el.addEventListener('pointerup',up);el.addEventListener('pointercancel',cancel);
 });
 el.addEventListener('keydown',e=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;e.preventDefault();const current=$('#'+side+'-slot').getBoundingClientRect().width;resizeSide(side,e.key==='Home'?216:e.key==='End'?400:current+(e.key==='ArrowRight'?8:-8)*(side==='left'?1:-1));persist();});
}
let suppressDragClick=false;
function installDnD(){document.addEventListener('pointerdown',e=>{
 if(e.button!==0)return;const grip=e.target.closest('[data-view-grip]'),row=e.target.closest('[data-node]');if(!grip&&!row)return;if(!grip&&e.target.closest('button,input'))return;
 const start={x:e.clientX,y:e.clientY},view=grip?.dataset.viewGrip,id=row?.dataset.node;const ids=id?(selected().includes(id)?selected():[id]):[];let dragging=false,targetSide=null,targetParent=null;
 const clean=()=>{activeCancel=null;document.body.classList.remove('moving-view','resizing');$$('.drop-over').forEach(x=>x.classList.remove('drop-over'));};
 const move=ev=>{if(!dragging&&Math.abs(ev.clientX-start.x)+Math.abs(ev.clientY-start.y)<7)return;dragging=true;hideMenus();hideTip();if(view)document.body.classList.add('moving-view');else document.body.classList.add('resizing');const hit=document.elementFromPoint(ev.clientX,ev.clientY);$$('.drop-over').forEach(x=>x.classList.remove('drop-over'));if(view){const slot=hit?.closest('.slot');targetSide=slot?(slot.id==='left-slot'?'left':'right'):null;}else{const scroll=hit?.closest('#tree-scroll');targetParent=null;if(scroll){const target=hit.closest('[data-node]'),tn=M.node(state,target?.dataset.node);targetParent=tn?(tn.type==='folder'?tn.id:tn.parent):'#';if(target)target.classList.add('drop-over');const r=scroll.getBoundingClientRect();if(ev.clientY<r.top+28)scroll.scrollTop-=8;if(ev.clientY>r.bottom-28)scroll.scrollTop+=8;}}};
 const up=()=>{window.removeEventListener('pointermove',move);window.removeEventListener('pointerup',up);window.removeEventListener('pointercancel',cancel);clean();if(dragging){suppressDragClick=true;setTimeout(()=>suppressDragClick=false,0);if(view&&targetSide)swapPanels(targetSide,view);else if(!view&&targetParent!==null){const ok=transact(s=>{M.move(s,ids,targetParent);if(targetParent!=='#'&&!s.openFolders.includes(targetParent))s.openFolders.push(targetParent);return true;},'拖动项目');if(ok)notify('已移动');}}};
 const cancel=()=>{window.removeEventListener('pointermove',move);window.removeEventListener('pointerup',up);window.removeEventListener('pointercancel',cancel);clean();};
 activeCancel=cancel;window.addEventListener('pointermove',move);window.addEventListener('pointerup',up);window.addEventListener('pointercancel',cancel);
 });}
function installCanvasDragging(){
 document.addEventListener('pointerdown',e=>{
  const view=e.target.closest('#canvas-view'),nodeEl=e.target.closest('[data-graph]');if(!view||e.button!==0||e.target.closest('.canvas-tools'))return;
  hideMenus();hideTip();e.preventDefault();
  const id=nodeEl?.dataset.graph,node=id?data().graph.find(x=>x.id===id):null,before=M.clone(state),start={x:e.clientX,y:e.clientY,nx:node?.x,ny:node?.y,offset:{...graphOffset}},zoom=graphZoom;
  let changed=false,collision=false;
  if(node){selectedGraph=id;paintGraph();$(`[data-graph="${id}"]`)?.focus({preventScroll:true});}else view.focus({preventScroll:true});
  const task=frameTask(point=>{const dx=point.x-start.x,dy=point.y-start.y;if(Math.abs(dx)+Math.abs(dy)>3)changed=true;if(!changed)return;
   if(node){node.x=Math.round(Math.max(0,Math.min(5000,start.nx+dx/zoom)));node.y=Math.round(Math.max(0,Math.min(5000,start.ny+dy/zoom)));collision=!!M.graphCollision(data().graph,id,node.x,node.y);}
   else graphOffset={x:start.offset.x+dx,y:start.offset.y+dy};paintGraph();
  });
  const move=ev=>task({x:ev.clientX,y:ev.clientY});
  const clean=()=>{task.cancel();window.removeEventListener('pointermove',move);window.removeEventListener('pointerup',up);window.removeEventListener('pointercancel',cancel);activeCancel=null;};
  const finish=()=>{paintGraph();saveGraphView();if(id)$(`[data-graph="${id}"]`)?.focus({preventScroll:true});};
  const cancel=()=>{if(node){node.x=start.nx;node.y=start.ny;}graphOffset=start.offset;clean();finish();};
  const up=()=>{task.flush();clean();if(node&&changed){if(collision){node.x=start.nx;node.y=start.ny;notify('与其他节点相交，已保留原位置','error');}
   else{undoState=before;state.revision++;state.events.push({id:M.uid(),time:M.now(),label:'拖动节点'});state.events=state.events.slice(-80);undoAfter=M.clone(state);persist();}}
   finish();};
  activeCancel=cancel;window.addEventListener('pointermove',move);window.addEventListener('pointerup',up);window.addEventListener('pointercancel',cancel);
 });
 const draw=frameTask(()=>{paintGraph();saveGraphView();});
 document.addEventListener('wheel',e=>{const view=e.target.closest('#canvas-view');if(!view||e.target.closest('.canvas-tools'))return;e.preventDefault();if(e.ctrlKey){const r=view.getBoundingClientRect();zoomGraph(graphZoom*Math.exp(-e.deltaY*.006),{x:e.clientX-r.left,y:e.clientY-r.top});}else{graphOffset.x-=e.deltaX;graphOffset.y-=e.deltaY;draw();}},{passive:false});
}
async function importFile(file){if(!file)return;if(file.size>2000000)return notify('文件大于 2 MB，请使用演示范围内的数据','error');try{const generation=++importGeneration,text=await file.text();if(generation!==importGeneration)return;const incoming=M.validate(JSON.parse(text));showDialog({title:'导入工作区？',description:`包含 ${incoming.nodes.length} 个项目，将替换当前演示内容。当前数据不会自动另存，请先导出需要保留的内容。`,submit:'导入',onSubmit:()=>{undoState=M.clone(state);state=incoming;undoAfter=M.clone(state);storageLocked=false;storageProblem='';query='';activity='files';navMode='files';surface='files';editMode=false;previewState='';persist();render();notify('工作区已导入','info',{label:'撤销',run:undo});return true;}});}catch(e){notify('导入失败：'+e.message,'error');}}

function trapDialog(e){
 if(e.key!=='Tab'||menus.length)return;const host=overlayHost();if(host===document.body)return;
 const list=$$('button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea:not(:disabled),a[href],[tabindex="0"]',host).filter(el=>focusVisible(el)&&el.tabIndex>=0);
 if(!list.length)return;e.stopPropagation();const first=list[0],last=list.at(-1);
 if(e.shiftKey&&(document.activeElement===first||!host.contains(document.activeElement))){e.preventDefault();last.focus();}
 else if(!e.shiftKey&&(document.activeElement===last||!host.contains(document.activeElement))){e.preventDefault();first.focus();}
}

function initialize(){WBSelect.configure({host:overlayHost,beforeOpen:()=>{hideMenus();hideTip();}});if(!$('#app'))document.body.insertAdjacentHTML('afterbegin',scaffold());shell();render();
document.addEventListener('click',e=>{if(suppressDragClick){suppressDragClick=false;return;}const command=e.target.closest('[data-command]');if(command)return executePalette(+command.dataset.command);const b=e.target.closest('[data-action]');if(b&&!b.disabled){dispatch(b,e);return;}const row=e.target.closest('[data-node]');if(row){const id=row.dataset.node;if(!e.ctrlKey&&!e.metaKey&&!e.shiftKey&&M.node(state,id)?.type!=='folder')openFile(id);else selectNode(id,e);}});
document.addEventListener('dblclick',e=>{const row=e.target.closest('[data-node]');if(row&&M.node(state,row.dataset.node)?.type==='folder')toggleFolder(row.dataset.node);const graph=e.target.closest('[data-graph]');if(graph)graphDialog(graph.dataset.graph);const tr=e.target.closest('[data-row]');if(tr)rowDialog(data().rows.find(r=>r.id===tr.dataset.row));});
document.addEventListener('contextmenu',e=>{if(e.target.closest('input,textarea,[contenteditable="true"]'))return;const ctx=previewContext(e);if(ctx){e.preventDefault();openMenu(ctx.items,e.clientX,e.clientY,ctx.el);}});
// Escape dismisses only the uppermost tooltip; a second Escape can close its parent dialog.
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('#tooltip').hidden){hideTip();e.preventDefault();e.stopImmediatePropagation();}},true);
document.addEventListener('compositionstart',e=>{if(e.target.id==='tree-search')queueTreeFilter.cancel();});document.addEventListener('input',handleInput);document.addEventListener('change',e=>{if(e.target.closest('.settings-modal'))refreshSettingsDirty();});document.addEventListener('compositionend',e=>{if(e.target.id==='list-search'){listQuery=e.target.value;paintTableRows();}else if(e.target.id==='tree-search'){query=e.target.value;queueTreeFilter();}else if(e.target.id==='command-input'){paletteIndex=0;filterPalette();}});document.addEventListener('keydown',trapDialog);document.addEventListener('keydown',onKey);
document.addEventListener('pointerdown',e=>{if(menus.length&&!e.target.closest('.menu')&&e.button===0){hideMenus(true);suppressOutsideClick=true;e.preventDefault();}hideTip();},true);document.addEventListener('click',e=>{if(suppressOutsideClick){suppressOutsideClick=false;e.preventDefault();e.stopImmediatePropagation();}},true);document.addEventListener('pointerup',()=>setTimeout(()=>suppressOutsideClick=false,0),true);document.addEventListener('pointerover',e=>{const b=e.target.closest('[data-tip]');if(b&&!b.contains(e.relatedTarget))requestTip(b);});document.addEventListener('pointerout',e=>{const b=e.target.closest('[data-tip]');if(b&&!b.contains(e.relatedTarget))deferHideTip();});document.addEventListener('focusin',e=>requestTip(e.target.closest('[data-tip]')));document.addEventListener('focusout',()=>deferHideTip());$('#tooltip').addEventListener('pointerenter',()=>clearTimeout(tooltipCloseTimer));$('#tooltip').addEventListener('pointerleave',deferHideTip);
document.addEventListener('keydown',e=>{if(e.target.id==='property-name'){if(e.key==='Enter'&&!e.isComposing){e.preventDefault();commitProperty(e.target);}else if(e.key==='Escape'){propertyDrafts.delete(e.target.dataset.id);e.target.value=M.node(state,e.target.dataset.id).name;e.target.removeAttribute('aria-invalid');$('#property-error').hidden=true;$('[data-action="apply-name"]').disabled=true;}}});
document.addEventListener('submit',e=>{if(e.target.id!=='modal-form')return;e.preventDefault();if(!$('#modal').open||modalBusy||!modalSubmit)return;modalBusy=true;try{const ok=modalSubmit(e.target);if(ok!==false)closeDialog();}catch(err){$('#dialog-error').textContent=err.message;$('#dialog-error').hidden=false;}finally{modalBusy=false;}});
$('#modal').addEventListener('cancel',e=>{e.preventDefault();closeDialog();});$('#palette').addEventListener('cancel',e=>{e.preventDefault();closePalette();});$('#drawer').addEventListener('cancel',e=>{e.preventDefault();closeDrawer();});
for(const id of ['modal','palette','drawer'])$('#'+id).addEventListener('click',e=>{if(e.target!==e.currentTarget)return;const r=e.currentTarget.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom){if(id==='modal')closeDialog();else if(id==='palette')closePalette();else closeDrawer();}});
$('#import-file').addEventListener('change',e=>{importFile(e.target.files[0]);e.target.value='';});installResize($('#split-left'),'left');installResize($('#split-right'),'right');installDnD();installCanvasDragging();
const reflow=frameTask(()=>{hideMenus(true);hideTip();if(drawerView&&(currentMode()==='wide'||currentMode()==='medium'&&physicalSide(drawerView)==='left'))closeDrawer();applyLayout();positionToast();});window.addEventListener('resize',()=>reflow());
window.addEventListener('storage',e=>{if(e.key===KEY){clearTimeout(persistTimer);persistTimer=null;persistPending=false;storageLocked=true;storageProblem='其他窗口已更新 · 请先导出当前副本';status(storageProblem,true);notify(storageProblem,'error');}});
window.addEventListener('pagehide',()=>{if(persistPending)persist();});document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden'&&persistPending)persist();});
if(storageProblem)notify(storageProblem+'；可先导出当前副本再导入恢复。','error');
globalThis.Workbench=Object.freeze({version:WBTokens.version,storageKey:KEY,snapshot:()=>M.clone(state),diagnostics:()=>({...runtimeStats,persistPending,activity,overlays:$$('.menu,.select-popup').length})});
}
initialize();
})();
