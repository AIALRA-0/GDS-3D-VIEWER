#!/usr/bin/env python3
"""Deterministically assemble the revision from a frozen original and explicit source modules.
No existing project files or historic distribution archives are modified.
"""
from pathlib import Path
import hashlib, json, re, argparse
ROOT=Path(__file__).resolve().parent
PACKAGE=ROOT.parent
JS_ORDER=['ui.js','flow.js','formats.js','assets.js','catalog.js','registry.js','charts.js','cases-foundation-actions.js','cases-navigation-input.js','cases-data-display.js','cases-feedback-overlays.js','cases-layout-visual.js','cases-workflow-enterprise.js','cases-media-collab.js','cases-access-ai.js','atlas.js','seeds.js']
CSS_ORDER=['ui.css','flow.css','formats.css','atlas.css']
BASE_SHA='ff4869bf676d7fd39a63286da1afaf21ed539af9173604a047610ee36997a052'

def build(output:Path)->str:
 raw=(ROOT/'baseline-v0.2.html').read_bytes()
 if hashlib.sha256(raw).hexdigest()!=BASE_SHA:raise ValueError('Frozen v0.2 input does not match the audited original')
 s=raw.decode('utf-8')
 def replace(old,new,count=1):
  nonlocal s
  actual=s.count(old)
  if actual!=count:raise ValueError(f'Expected {count} source anchor(s), got {actual}: {old[:100]}')
  s=s.replace(old,new,count)
 css='\n'.join((ROOT/x).read_text('utf-8') for x in CSS_ORDER)
 js='\n'.join((ROOT/x).read_text('utf-8') for x in JS_ORDER)
 # Prevent user-controlled script closing sequences from escaping the single script block.
 if re.search(r'</script',js,re.I):raise ValueError('Unexpected closing script sequence in revision source')
 s=s.replace('</style>', '\n/* Design Atlas v0.5-r1: generated revision CSS */\n'+css+'\n</style>',1)
 s=s.replace('<script id="app-code">','<script id="studio-code">'+js+'</script><script id="app-code">',1)
 replace("const KEY='aialra.workbench.v2.'+hash(location.pathname);","const KEY='aialra.workbench.v05r1.'+hash(location.pathname);")
 replace('delete seed.listRows;delete seed.graph;delete seed.edges;return seed;', 'delete seed.listRows;delete seed.graph;delete seed.edges;return StudioSeeds.make(seed);')
 # Correct target: the independent pre-title grip/menu button. No invisible spacer is substituted.
 grip='<button class="icon-button grip" draggable="false" data-view-grip="${view}" data-action="panel-menu" data-view="${view}" aria-label="拖动或迁移${title}" data-tip="拖动迁移；点击打开布局菜单">${I(\'grip\')}</button>'
 replace(grip,'')
 replace('${iconButton(\'swap\',\'移至另一侧\',\'swap-panels\',`data-view="${view}"`)}','')
 # Preserve the global side-swap action and menu-based alternate path; remove only redundant chrome.
 # Protect all module-owned text and names from the old Chinese translation observer.
 replace("const PROTECTED='script,style", "const PROTECTED='.case-atlas,.format-viewer,.flow-editor,.st-dialog,.st-popover,.st-tooltip,.st-select-list,script,style")
 replace('function localizeAttrs(el,locale){',"function localizeAttrs(el,locale){if(el.closest('.case-atlas,.format-viewer,.flow-editor,.st-dialog,.st-popover,.st-tooltip,.st-select-list'))return;")
 replace('function validatePayload(n){',"""function validatePayload(n){
 if(n.format!==undefined&&(!WBFormats.allowed.includes(n.format)||n.type!=='document'))fail('Unsupported native format metadata');
 if(n.format&&['png','wav'].includes(n.format)){const prefix=n.format==='png'?'data:image/png;base64,':'data:audio/wav;base64,';if(!n.content.startsWith(prefix))fail('Invalid embedded native asset');}
 if(n.payload?.studioFlow)WBFlow.validate(n.payload.studioFlow);
 """)
 replace('function renderMain(){rememberView();','function renderMain(){disposeStudio();rememberView();')
 anchor=" if(f.type==='document'){if(editMode){"
 replace(anchor," if(f.type==='document'&&f.format){renderStudioFile(f);return;}\n"+anchor)
 a=s.index('function renderCanvas(){');b=s.index('function saveGraphView()',a)
 s=s[:a]+"function renderCanvas(){renderStudioCanvas(n());}\n"+s[b:]
 a=s.index('function renderComponents(){');b=s.index('function hideMenus(',a)
 s=s[:a]+"""function renderComponents(){const c=$('#main-content');$('#breadcrumb').textContent=state.config.locale==='en'?'Component specimens':'组件参照';$('#view-tools').innerHTML='';$('#save-state').textContent=state.config.locale==='en'?'289 explicit specimens · local sandbox':'289 个独立登记案例 · 本地沙盒';$('#main-meta').textContent='Design v0.1 · v0.5-r1';c.innerHTML=WBAtlas.render(state.config.locale);WBAtlas.attach(c);}
"""+s[b:]
 replace('function toggleLanguage(){state.config.locale=state.config.locale===\'zh\'?\'en\':\'zh\';updateLanguageButton();WBI18n.setLanguage(state.config.locale);scheduleViewPersist();}',"function toggleLanguage(){state.config.locale=state.config.locale==='zh'?'en':'zh';updateLanguageButton();WBI18n.setLanguage(state.config.locale);if(surface==='components')WBAtlas.setLocale(state.config.locale);else if(n()?.format||n()?.type==='canvas')renderMain();scheduleViewPersist();}")
 replace('function onKey(e){',"function onKey(e){if(e.target.closest('.case-atlas,.flow-editor,.format-viewer,.st-dialog,.st-popover,.st-select-list'))return;")
 # Module source participates in exported standalone HTML, not only the initial preview.
 replace("const js=$('#app-code').textContent,css=$('#design-style').textContent", "const js=$('#app-code').textContent,studio=$('#studio-code').textContent,css=$('#design-style').textContent")
 replace("+'<script id=\"app-code\">'+js+closeScript", "+'<script id=\"studio-code\">'+studio+closeScript+'<script id=\"app-code\">'+js+closeScript")
 replace('function initialize(){', (ROOT/'shell-extension.js').read_text('utf-8')+'\nfunction initialize(){')
 replace("version:WBTokens.version,storageKey:KEY,snapshot:","version:'v0.5-r1',storageKey:KEY,openSample:id=>openFile(id),openAtlas:()=>{surface='components';activity='components';render();},snapshot:")
 replace('initialize();\n})();','initialize();\nif(location.hash===\'#canvas\')openFile(\'sample-canvas\');else if(location.hash===\'#atlas\'){surface=\'components\';activity=\'components\';render();}\n})();')
 replace('<span class="optional">IT-005</span><span>2.3</span>','<span class="optional">Design v0.1</span><span>v0.5-r1</span>')
 replace('- 参照：AIALRA Workbench v${WBTokens.version} / DESIGN.md','- 当前可选组件：Design Atlas v0.5-r1\\n- 正式设计规则：Design v0.1\\n- 历史 UI 基座：AIALRA Workbench v${WBTokens.version}')
 replace('<title>AIALRA Workbench</title>','<title>AIALRA Design Studio · v0.5-r1</title>')
 output.parent.mkdir(parents=True,exist_ok=True);output.write_bytes(s.encode('utf-8'))
 return hashlib.sha256(output.read_bytes()).hexdigest()
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,default=PACKAGE/'demo/Workbench-v0.5-r1.html');args=p.parse_args();print(json.dumps({'output':str(args.output),'sha256':build(args.output)},ensure_ascii=False))
