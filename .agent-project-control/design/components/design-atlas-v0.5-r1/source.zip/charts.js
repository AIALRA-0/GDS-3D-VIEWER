/* Synthetic chart fixtures with explicit numeric equivalents and hover/focus targets. */
(function(g){'use strict';const E=g.StudioUI.esc;
function chart(kind,values=[38,64,48,83,57],labels=['Mon','Tue','Wed','Thu','Fri'],unit='items'){
 const W=640,H=230,pts=values.map((v,i)=>({x:55+i*(520/Math.max(1,values.length-1)),y:185-v*1.6,v,label:labels[i]||String(i+1)}));
 const target=(text)=>` tabindex="0" data-st-tip="${E(text)}" aria-label="${E(text)}"`;
 const rect=(x,y,w,h,text,cls='')=>`<rect x="${x}" y="${y}" width="${Math.max(.5,w)}" height="${Math.max(.5,h)}" rx="3" class="chart-fill ${cls}"${target(text)}/>`;
 const circle=(x,y,r,text,cls='')=>`<circle cx="${x}" cy="${y}" r="${r}" class="chart-fill ${cls}"${target(text)}/>`;
 const text=(x,y,s,cls='')=>`<text x="${x}" y="${y}" class="${cls}">${E(s)}</text>`;
 const datum=(v,i)=>`${labels[i]||i+1} · ${v} ${unit}`;
 let content='',table=values.map((v,i)=>[labels[i]||String(i+1),v+' '+unit]);
 const axis=`<path d="M38 20v174h565" class="chart-axis"/>${[0,25,50,75,100].map(v=>text(5,190-v*1.6,v)).join('')}`;
 if(['line','area','time','sparkline'].includes(kind)){
 const d=pts.map((p,i)=>(i?'L':'M')+p.x+' '+p.y).join(' ');content=(kind==='sparkline'?'':axis)+(kind==='area'?`<path d="${d} L575 190 L55 190Z" class="chart-area"${target('Series total · '+values.reduce((a,b)=>a+b,0)+' '+unit)}/>`:'')+`<path d="${d}" class="chart-line"/>`+pts.map((p,i)=>circle(p.x,p.y,7,datum(p.v,i))+text(p.x-10,215,labels[i])).join('');
 }else if(['pie','donut'].includes(kind)){
 let a=-Math.PI/2,sum=values.reduce((a,b)=>a+b,0);content=values.map((v,i)=>{const start=a,end=a+v/sum*2*Math.PI;a=end;const p=(a,r)=>[180+Math.cos(a)*r,110+Math.sin(a)*r];const A=p(start,90),B=p(end,90),large=end-start>Math.PI?1:0;const path=kind==='pie'?`M180 110 L${A} A90 90 0 ${large} 1 ${B}Z`:`M${A} A90 90 0 ${large} 1 ${B} L${p(end,53)} A53 53 0 ${large} 0 ${p(start,53)}Z`;return `<path d="${path}" class="chart-fill tone-${i%5}"${target(datum(v,i)+' · '+(100*v/sum).toFixed(1)+'%')}/>`+rect(340,30+i*35,16,16,datum(v,i),'tone-'+i)+text(366,43+i*35,datum(v,i))}).join('');if(kind==='donut')content+=text(159,117,sum,'chart-number');
 }else if(kind==='scatter'){
 const ds=[[12,30],[35,64],[58,49],[70,88],[86,65]];content=axis+ds.map(([x,y],i)=>circle(40+x*5.5,190-y*1.6,7,`${labels[i]} · x=${x}, y=${y}`)).join('');table=ds.map(([x,y],i)=>[labels[i],`x=${x}, y=${y}`]);
 }else if(kind==='heatmap'){
 table=[];for(let row=0;row<4;row++)for(let col=0;col<7;col++){const v=5+(row*13+col*17)%95,label=`W${row+1} / D${col+1}`;content+=`<rect x="${55+col*72}" y="${15+row*44}" width="62" height="34" rx="4" class="chart-fill" opacity="${.22+.78*v/100}"${target(label+' · '+v+' '+unit)}/>`;table.push([label,v+' '+unit])}for(let i=0;i<7;i++)content+=text(70+i*72,211,'D'+(i+1));
 }else if(kind==='treemap'){
 const regions=[[35,15,308,175,55,'Storage'],[343,15,252,97.222222,25,'Compute'],[343,112.222222,126,77.777778,10,'Network'],[469,112.222222,126,77.777778,10,'Other']];content=regions.map(([x,y,w,h,v,n],i)=>rect(x,y,w,h,n+' · '+v+'%','tone-'+i)+text(x+13,y+25,n)+text(x+13,y+47,v+'%')).join('');table=regions.map(r=>[r[5],r[4]+'%']);
 }else if(kind==='funnel'){
 let vals=[100,78,53,31],labs=['Visit','Register','Verify','Activate'];content=vals.map((v,i)=>rect(320-v*2.5,10+i*49,v*5,38,`${labs[i]} · ${v}%`,'tone-'+i)+text(285,35+i*49,`${labs[i]} ${v}%`)).join('');table=labs.map((l,i)=>[l,vals[i]+'%']);
 }else if(kind==='gantt'){
 const tasks=[['Design',0,3],['Build',2,6],['Test',5,8],['Review',7,9]];content=tasks.map(([n,a,b],i)=>text(15,45+i*42,n)+rect(110+a*45,25+i*42,(b-a)*45,27,`${n} · day ${a+1}–${b} · ${b-a} days`,'tone-'+i)).join('');table=tasks.map(([n,a,b])=>[n,`D${a+1}–D${b}`]);
 }else if(kind==='map'){
 const zones=[['North',60,20,65],['East',390,85,41],['South',235,138,73],['West',62,100,29],['Central',240,55,53]];content=zones.map(([n,x,y,v],i)=>rect(x,y,130,58,`${n} (synthetic) · ${v} ${unit}`,'tone-'+i)+text(x+10,y+23,n)+text(x+10,y+44,v)).join('');table=zones.map(([n,x,y,v])=>[n+' (synthetic region)',v+' '+unit]);
 }else if(kind==='network'){
 const ns=[['Input',80,110,18],['Index',290,45,42],['Search',300,170,36],['Answer',530,105,57]];content=`<path d="M80 110 290 45 530 105 300 170 80 110" class="chart-line"/>`+ns.map(([n,x,y,v])=>circle(x,y,24,`${n} · ${v} ms`)+text(x-23,y+43,n)).join('');table=ns.map(([n,x,y,v])=>[n,v+' ms']);
 }else if(kind==='sankey'){
 const links=[['Visits → Qualified',75,70,280,90,35,70],['Visits → Dropped',75,70,280,180,15,30],['Qualified → Paid',300,90,545,65,20,40],['Qualified → Trial',300,90,545,145,15,30]];content=links.map(([l,x,y,xx,yy,w,v])=>`<path d="M${x} ${y} C${(x+xx)/2} ${y},${(x+xx)/2} ${yy},${xx} ${yy}" class="chart-sankey" stroke-width="${w}"${target(l+' · '+v+' users')}/>`).join('')+rect(55,30,20,100,'Visits · 100 users')+rect(280,55,20,70,'Qualified · 70 users')+rect(280,163,20,32,'Dropped · 30 users')+rect(545,40,20,45,'Paid · 40 users')+rect(545,125,20,34,'Trial · 30 users');table=links.map(x=>[x[0],x[6]+' users']);
 }else if(kind==='coordinate'){
 content=`<path d="M320 15v192M20 110h595" class="chart-axis"/>`+[[1,3],[-3,2],[-2,-2],[4,-1]].map(([x,y],i)=>circle(320+x*45,110-y*25,8,`P${i+1} · (${x}, ${y})`)+text(330+x*45,105-y*25,`P${i+1}`)).join('');table=[[1,3],[-3,2],[-2,-2],[4,-1]].map((p,i)=>['P'+(i+1),p.join(', ')]);
 }else{
 content=axis+values.map((v,i)=>rect(64+i*105,190-v*1.6,58,v*1.6,datum(v,i),'tone-'+i)+text(68+i*105,214,labels[i]||String(i+1))).join('');
 }
 return `<div class="case-chart"><svg viewBox="0 0 ${W} ${H}" role="group" aria-label="${E(kind+' chart · synthetic data')}">${content}</svg></div><details class="case-chart-data"><summary>↳ ${g.document?.documentElement?.lang==='en'?'Exact values':'精确数值表'}</summary>${g.CaseRegistry.table(['Item','Value'],table.map(r=>r.map(E)))}</details>`;
}
g.StudioCharts={chart};
})(globalThis);
